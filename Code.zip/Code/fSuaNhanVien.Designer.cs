﻿namespace QL_Bida
{
    partial class fSuaNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fSuaNhanVien));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtTen = new TextBox();
            panel1 = new Panel();
            pnlTaiKhoan = new Panel();
            label10 = new Label();
            btnXemMK = new Button();
            lblTenDangNHap = new Label();
            panel8 = new Panel();
            txtTenDangNhap = new TextBox();
            panel3 = new Panel();
            txtMatKhau = new TextBox();
            panel4 = new Panel();
            txtXacNhanMK = new TextBox();
            lblMatKhau = new Label();
            lblXacNhanMK = new Label();
            dateTimePicker1 = new DateTimePicker();
            cboCa = new ComboBox();
            cboVaiTro = new ComboBox();
            cboGioiTinh = new ComboBox();
            btnLuu = new Button();
            btnHuyBo = new Button();
            btnGiup = new Button();
            groupBox1 = new GroupBox();
            pictureBox1 = new PictureBox();
            btnXoaAnh = new Button();
            btnChonAnh = new Button();
            pbAnhDaiDien = new PictureBox();
            label20 = new Label();
            label21 = new Label();
            label9 = new Label();
            label7 = new Label();
            label25 = new Label();
            label5 = new Label();
            label8 = new Label();
            label6 = new Label();
            label24 = new Label();
            label4 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            pnlTaiKhoan.SuspendLayout();
            panel8.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbAnhDaiDien).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(8, 21);
            label1.Name = "label1";
            label1.Size = new Size(146, 28);
            label1.TabIndex = 1;
            label1.Text = "Sửa nhân viên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label2.Location = new Point(28, 81);
            label2.Name = "label2";
            label2.Size = new Size(156, 31);
            label2.TabIndex = 0;
            label2.Text = "Tên nhân viên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F);
            label3.ForeColor = Color.Red;
            label3.Location = new Point(177, 81);
            label3.Name = "label3";
            label3.Size = new Size(32, 28);
            label3.TabIndex = 1;
            label3.Text = "(*)";
            // 
            // txtTen
            // 
            txtTen.BackColor = Color.Silver;
            txtTen.BorderStyle = BorderStyle.None;
            txtTen.Font = new Font("Segoe UI", 25F);
            txtTen.Location = new Point(16, 4);
            txtTen.Name = "txtTen";
            txtTen.Size = new Size(706, 56);
            txtTen.TabIndex = 2;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pnlTaiKhoan);
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(cboCa);
            panel1.Controls.Add(cboVaiTro);
            panel1.Controls.Add(cboGioiTinh);
            panel1.Controls.Add(btnLuu);
            panel1.Controls.Add(btnHuyBo);
            panel1.Controls.Add(btnGiup);
            panel1.Controls.Add(groupBox1);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label25);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label24);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(panel2);
            panel1.Font = new Font("Arial", 9F, FontStyle.Italic, GraphicsUnit.Point, 163);
            panel1.Location = new Point(8, 69);
            panel1.Name = "panel1";
            panel1.Size = new Size(1457, 696);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // pnlTaiKhoan
            // 
            pnlTaiKhoan.Controls.Add(label10);
            pnlTaiKhoan.Controls.Add(btnXemMK);
            pnlTaiKhoan.Controls.Add(lblTenDangNHap);
            pnlTaiKhoan.Controls.Add(panel8);
            pnlTaiKhoan.Controls.Add(panel3);
            pnlTaiKhoan.Controls.Add(panel4);
            pnlTaiKhoan.Controls.Add(lblMatKhau);
            pnlTaiKhoan.Controls.Add(lblXacNhanMK);
            pnlTaiKhoan.Location = new Point(28, 308);
            pnlTaiKhoan.Name = "pnlTaiKhoan";
            pnlTaiKhoan.Size = new Size(973, 341);
            pnlTaiKhoan.TabIndex = 17;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = Color.Red;
            label10.Location = new Point(527, 181);
            label10.Name = "label10";
            label10.Size = new Size(443, 17);
            label10.TabIndex = 7;
            label10.Text = "(Đây là mật khẩu hiện tại của bạn. Nếu muốn thay đổi xin nhập lại!)";
            // 
            // btnXemMK
            // 
            btnXemMK.BackColor = Color.DarkGray;
            btnXemMK.BackgroundImage = (Image)resources.GetObject("btnXemMK.BackgroundImage");
            btnXemMK.BackgroundImageLayout = ImageLayout.Zoom;
            btnXemMK.Location = new Point(487, 168);
            btnXemMK.Name = "btnXemMK";
            btnXemMK.Size = new Size(44, 37);
            btnXemMK.TabIndex = 6;
            btnXemMK.UseVisualStyleBackColor = false;
            btnXemMK.Click += btnXemMK_Click;
            // 
            // lblTenDangNHap
            // 
            lblTenDangNHap.AutoSize = true;
            lblTenDangNHap.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            lblTenDangNHap.Location = new Point(3, 45);
            lblTenDangNHap.Name = "lblTenDangNHap";
            lblTenDangNHap.Size = new Size(167, 31);
            lblTenDangNHap.TabIndex = 0;
            lblTenDangNHap.Text = "Tên đăng nhập";
            // 
            // panel8
            // 
            panel8.BackColor = Color.Silver;
            panel8.Controls.Add(txtTenDangNhap);
            panel8.Location = new Point(225, 28);
            panel8.Margin = new Padding(3, 14, 3, 3);
            panel8.Name = "panel8";
            panel8.Size = new Size(737, 66);
            panel8.TabIndex = 4;
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.BackColor = Color.Silver;
            txtTenDangNhap.BorderStyle = BorderStyle.None;
            txtTenDangNhap.Font = new Font("Segoe UI", 26F);
            txtTenDangNhap.Location = new Point(16, 5);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(706, 58);
            txtTenDangNhap.TabIndex = 2;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Silver;
            panel3.Controls.Add(txtMatKhau);
            panel3.Location = new Point(225, 139);
            panel3.Margin = new Padding(3, 14, 3, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(256, 66);
            panel3.TabIndex = 4;
            // 
            // txtMatKhau
            // 
            txtMatKhau.BackColor = Color.Silver;
            txtMatKhau.BorderStyle = BorderStyle.None;
            txtMatKhau.Font = new Font("Segoe UI", 26F);
            txtMatKhau.Location = new Point(16, 5);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(230, 58);
            txtMatKhau.TabIndex = 2;
            txtMatKhau.UseSystemPasswordChar = true;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Silver;
            panel4.Controls.Add(txtXacNhanMK);
            panel4.Location = new Point(225, 237);
            panel4.Margin = new Padding(3, 14, 3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(256, 66);
            panel4.TabIndex = 4;
            // 
            // txtXacNhanMK
            // 
            txtXacNhanMK.BackColor = Color.Silver;
            txtXacNhanMK.BorderStyle = BorderStyle.None;
            txtXacNhanMK.Font = new Font("Segoe UI", 26F);
            txtXacNhanMK.Location = new Point(16, 5);
            txtXacNhanMK.Name = "txtXacNhanMK";
            txtXacNhanMK.Size = new Size(230, 58);
            txtXacNhanMK.TabIndex = 2;
            txtXacNhanMK.UseSystemPasswordChar = true;
            // 
            // lblMatKhau
            // 
            lblMatKhau.AutoSize = true;
            lblMatKhau.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            lblMatKhau.Location = new Point(3, 156);
            lblMatKhau.Name = "lblMatKhau";
            lblMatKhau.Size = new Size(111, 31);
            lblMatKhau.TabIndex = 0;
            lblMatKhau.Text = "Mật khẩu";
            // 
            // lblXacNhanMK
            // 
            lblXacNhanMK.AutoSize = true;
            lblXacNhanMK.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            lblXacNhanMK.Location = new Point(3, 254);
            lblXacNhanMK.Name = "lblXacNhanMK";
            lblXacNhanMK.Size = new Size(210, 31);
            lblXacNhanMK.TabIndex = 0;
            lblXacNhanMK.Text = "Xác nhận mật khẩu";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            dateTimePicker1.Format = DateTimePickerFormat.Short;
            dateTimePicker1.Location = new Point(741, 166);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(246, 38);
            dateTimePicker1.TabIndex = 16;
            // 
            // cboCa
            // 
            cboCa.BackColor = Color.Silver;
            cboCa.FlatStyle = FlatStyle.Flat;
            cboCa.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            cboCa.FormattingEnabled = true;
            cboCa.Location = new Point(741, 263);
            cboCa.Name = "cboCa";
            cboCa.Size = new Size(246, 39);
            cboCa.TabIndex = 5;
            // 
            // cboVaiTro
            // 
            cboVaiTro.BackColor = Color.Silver;
            cboVaiTro.FlatStyle = FlatStyle.Flat;
            cboVaiTro.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            cboVaiTro.FormattingEnabled = true;
            cboVaiTro.Location = new Point(250, 263);
            cboVaiTro.Name = "cboVaiTro";
            cboVaiTro.Size = new Size(246, 39);
            cboVaiTro.TabIndex = 5;
            cboVaiTro.SelectedIndexChanged += cboVaiTro_SelectedIndexChanged;
            // 
            // cboGioiTinh
            // 
            cboGioiTinh.BackColor = Color.Silver;
            cboGioiTinh.FlatStyle = FlatStyle.Flat;
            cboGioiTinh.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            cboGioiTinh.FormattingEnabled = true;
            cboGioiTinh.Location = new Point(250, 161);
            cboGioiTinh.Name = "cboGioiTinh";
            cboGioiTinh.Size = new Size(246, 39);
            cboGioiTinh.TabIndex = 5;
            // 
            // btnLuu
            // 
            btnLuu.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnLuu.Image = Properties.Resources.save_24;
            btnLuu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLuu.Location = new Point(1074, 630);
            btnLuu.Margin = new Padding(3, 3, 3, 7);
            btnLuu.Name = "btnLuu";
            btnLuu.Padding = new Padding(18, 0, 0, 0);
            btnLuu.Size = new Size(116, 59);
            btnLuu.TabIndex = 13;
            btnLuu.Text = "Lưu";
            btnLuu.UseCompatibleTextRendering = true;
            btnLuu.UseVisualStyleBackColor = true;
            btnLuu.Click += btnLuu_Click;
            // 
            // btnHuyBo
            // 
            btnHuyBo.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnHuyBo.Image = Properties.Resources.cancel_24;
            btnHuyBo.ImageAlign = ContentAlignment.MiddleLeft;
            btnHuyBo.Location = new Point(1196, 629);
            btnHuyBo.Margin = new Padding(3, 3, 3, 7);
            btnHuyBo.Name = "btnHuyBo";
            btnHuyBo.Padding = new Padding(18, 0, 0, 0);
            btnHuyBo.Size = new Size(133, 60);
            btnHuyBo.TabIndex = 14;
            btnHuyBo.Text = "Huỷ bỏ";
            btnHuyBo.TextAlign = ContentAlignment.MiddleRight;
            btnHuyBo.UseCompatibleTextRendering = true;
            btnHuyBo.UseVisualStyleBackColor = true;
            btnHuyBo.Click += btnHuyBo_Click;
            // 
            // btnGiup
            // 
            btnGiup.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnGiup.Image = Properties.Resources.help_24;
            btnGiup.ImageAlign = ContentAlignment.MiddleLeft;
            btnGiup.Location = new Point(1334, 630);
            btnGiup.Margin = new Padding(9, 3, 7, 7);
            btnGiup.Name = "btnGiup";
            btnGiup.Padding = new Padding(6, 0, 0, 0);
            btnGiup.Size = new Size(116, 59);
            btnGiup.TabIndex = 15;
            btnGiup.Text = "Giúp";
            btnGiup.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnGiup.UseCompatibleTextRendering = true;
            btnGiup.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Silver;
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(btnXoaAnh);
            groupBox1.Controls.Add(btnChonAnh);
            groupBox1.Controls.Add(pbAnhDaiDien);
            groupBox1.Controls.Add(label20);
            groupBox1.Controls.Add(label21);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            groupBox1.Location = new Point(1007, 37);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(444, 415);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ảnh đại diện";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(29, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(309, 256);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // btnXoaAnh
            // 
            btnXoaAnh.BackColor = Color.White;
            btnXoaAnh.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoaAnh.ForeColor = Color.Red;
            btnXoaAnh.Location = new Point(376, 103);
            btnXoaAnh.Margin = new Padding(35, 17, 3, 3);
            btnXoaAnh.Name = "btnXoaAnh";
            btnXoaAnh.Size = new Size(42, 42);
            btnXoaAnh.TabIndex = 1;
            btnXoaAnh.Text = "X";
            btnXoaAnh.UseVisualStyleBackColor = false;
            btnXoaAnh.Click += btnXoaAnh_Click;
            // 
            // btnChonAnh
            // 
            btnChonAnh.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnChonAnh.Location = new Point(376, 41);
            btnChonAnh.Margin = new Padding(35, 3, 3, 3);
            btnChonAnh.Name = "btnChonAnh";
            btnChonAnh.Size = new Size(42, 42);
            btnChonAnh.TabIndex = 1;
            btnChonAnh.Text = "...";
            btnChonAnh.UseVisualStyleBackColor = false;
            btnChonAnh.Click += btnChonAnh_Click;
            // 
            // pbAnhDaiDien
            // 
            pbAnhDaiDien.Location = new Point(29, 41);
            pbAnhDaiDien.Margin = new Padding(26, 18, 3, 3);
            pbAnhDaiDien.Name = "pbAnhDaiDien";
            pbAnhDaiDien.Size = new Size(309, 256);
            pbAnhDaiDien.TabIndex = 0;
            pbAnhDaiDien.TabStop = false;
            // 
            // label20
            // 
            label20.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label20.Location = new Point(29, 313);
            label20.Margin = new Padding(3, 13, 3, 0);
            label20.Name = "label20";
            label20.Size = new Size(309, 34);
            label20.TabIndex = 0;
            label20.Text = "Chọn các ảnh có định dạng\r\n\r\n";
            // 
            // label21
            // 
            label21.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label21.Location = new Point(23, 340);
            label21.Margin = new Padding(3, 13, 3, 0);
            label21.Name = "label21";
            label21.Size = new Size(309, 34);
            label21.TabIndex = 0;
            label21.Text = "(.jpg, .jeg, .png, .gif)";
            label21.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F);
            label9.ForeColor = Color.Red;
            label9.Location = new Point(672, 266);
            label9.Name = "label9";
            label9.Size = new Size(32, 28);
            label9.TabIndex = 1;
            label9.Text = "(*)";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.ForeColor = Color.Red;
            label7.Location = new Point(181, 266);
            label7.Name = "label7";
            label7.Size = new Size(32, 28);
            label7.TabIndex = 1;
            label7.Text = "(*)";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Segoe UI", 12F);
            label25.ForeColor = Color.Red;
            label25.Location = new Point(699, 166);
            label25.Name = "label25";
            label25.Size = new Size(32, 28);
            label25.TabIndex = 1;
            label25.Text = "(*)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F);
            label5.ForeColor = Color.Red;
            label5.Location = new Point(181, 164);
            label5.Name = "label5";
            label5.Size = new Size(32, 28);
            label5.TabIndex = 1;
            label5.Text = "(*)";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label8.Location = new Point(527, 266);
            label8.Name = "label8";
            label8.Size = new Size(131, 31);
            label8.TabIndex = 0;
            label8.Text = "Ca làm việc";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label6.Location = new Point(28, 266);
            label6.Name = "label6";
            label6.Size = new Size(82, 31);
            label6.TabIndex = 0;
            label6.Text = "Vai trò";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label24.Location = new Point(527, 166);
            label24.Name = "label24";
            label24.Size = new Size(118, 31);
            label24.TabIndex = 0;
            label24.Text = "Ngày sinh";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 13.5F, FontStyle.Bold);
            label4.Location = new Point(28, 164);
            label4.Name = "label4";
            label4.Size = new Size(102, 31);
            label4.TabIndex = 0;
            label4.Text = "Giới tính";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Silver;
            panel2.Controls.Add(txtTen);
            panel2.Location = new Point(250, 64);
            panel2.Margin = new Padding(3, 37, 19, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(737, 66);
            panel2.TabIndex = 4;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(1405, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(45, 47);
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // fSuaNhanVien
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.Firebrick;
            ClientSize = new Size(1462, 772);
            ControlBox = false;
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            ForeColor = SystemColors.ControlText;
            Name = "fSuaNhanVien";
            StartPosition = FormStartPosition.CenterParent;
            Load += fSuaNhanVien_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            pnlTaiKhoan.ResumeLayout(false);
            pnlTaiKhoan.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbAnhDaiDien).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void InitializeCustomComponents()
        {
            this.BackColor = Color.White;
            this.Size = new Size(1489, 795);

            // Create a Panel as a container
            Panel mainPanel = new Panel()
            {
                Size = new Size(1489, 795),
                Location = new Point(0, 0),
                BackColor = Color.White
            };
            this.Controls.Add(mainPanel);

            // Background Rectangle (as a panel here)
            Panel backgroundRectangle = new Panel()
            {
                Size = new Size(1489, 795),
                Location = new Point(0, 0),
                BackColor = Color.LightGray
            };
            mainPanel.Controls.Add(backgroundRectangle);

            // Inner Rectangle
            Panel innerRectangle = new Panel()
            {
                Size = new Size(1457, 696),
                Location = new Point(12, 85),
                BackColor = Color.WhiteSmoke
            };
            mainPanel.Controls.Add(innerRectangle);

            // Text "Thêm nhân viên"
            Label titleLabel = new Label()
            {
                Text = "Thêm nhân viên",
                Location = new Point(21, 20),
                Size = new Size(334, 38),
                Font = new Font("Arial", 16, FontStyle.Bold)
            };
            mainPanel.Controls.Add(titleLabel);

            // Save Button
            Button saveButton = new Button()
            {
                Text = "Lưu",
                Location = new Point(1071, 714),
                Size = new Size(123, 59),
                BackColor = Color.LightBlue
            };
            mainPanel.Controls.Add(saveButton);
        }

#endregion
        private Label label2;
        private Label label3;
        private Panel panel1;
        private Panel panel2;
        private Label label5;
        private Label label4;
        private Label label9;
        private Label label8;
        private Panel panel6;
        private TextBox txtSoCMND;
        private Label lblTenDangNHap;
        private Panel panel8;
        private Label label23;
        private Label label22;
        private DateTimePicker dtNgaySinh;
        private DateTimePicker dtNgayCap;
        private Button btnHuyBo;
        private Button btnGiup;
        private PictureBox pictureBox2;
        private Label label7;
        private Label label25;
        private Label label6;
        private Label label24;
        private GroupBox groupBox1;
        private PictureBox pictureBox1;
        private Button btnXoaAnh;
        private Button btnChonAnh;
        private PictureBox pbAnhDaiDien;
        private Label label20;
        private Label label21;
        private ComboBox comboBox2;
        private Label label27;
        private Label label26;
        private Panel panel3;
        public Label label1;
        public Button btnLuu;
        public Label lblXacNhanMK;
        public TextBox txtXacNhanMK;
        public Panel panel4;
        public TextBox txtTen;
        public TextBox txtTenDangNhap;
        public ComboBox cboGioiTinh;
        public ComboBox cboVaiTro;
        public ComboBox cboCa;
        public DateTimePicker dateTimePicker1;
        public Label lblMatKhau;
        public Panel pnlTaiKhoan;
        public TextBox txtMatKhau;
        public Button btnXemMK;
        public Label label10;
    }
}