﻿namespace QL_Bida
{
    partial class fNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel3 = new Panel();
            btnThucDon = new Button();
            btnQuanLyBan = new Button();
            btnKhachHang = new Button();
            btnLichSu = new Button();
            panel1 = new Panel();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            tabPage2 = new TabPage();
            pnlQuanLyBan = new Panel();
            flpQuanLyBan = new FlowLayoutPanel();
            pnl_top_QuanLyban = new Panel();
            label5 = new Label();
            label4 = new Label();
            panel9 = new Panel();
            panel8 = new Panel();
            cboLoai = new ComboBox();
            cboTrangThai = new ComboBox();
            panel4 = new Panel();
            btnUser_Ban = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            xemThôngTinToolStripMenuItem = new ToolStripMenuItem();
            đổiMậtKhẩuToolStripMenuItem = new ToolStripMenuItem();
            btnThoat_Ban = new Button();
            lblUserName_Ban = new Label();
            panel14 = new Panel();
            panel13 = new Panel();
            label1 = new Label();
            tabPage1 = new TabPage();
            pnlThucDon = new Panel();
            pnlThongTinMon = new Panel();
            label9 = new Label();
            panel2 = new Panel();
            label8 = new Label();
            label3 = new Label();
            label2 = new Label();
            btnGui = new Button();
            fplChiTietHoaDon = new FlowLayoutPanel();
            btnHuy = new Button();
            lblTongTien = new Label();
            fplThucDon = new FlowLayoutPanel();
            panel5 = new Panel();
            cboBan = new ComboBox();
            pnlKhac = new Panel();
            flowLayoutPanel4 = new FlowLayoutPanel();
            pnlBanh = new Panel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            pnlTra = new Panel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            pnlCoffe = new Panel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            btnKhac = new Button();
            btnBanh = new Button();
            btnTra = new Button();
            btnCoffe = new Button();
            txtTimKiem_ThucDon = new TextBox();
            panel10 = new Panel();
            btnUser_ThucDon = new Button();
            btnThoat_ThucDon = new Button();
            lblUsername_TD = new Label();
            panel11 = new Panel();
            panel12 = new Panel();
            label7 = new Label();
            tabControl1 = new TabControl();
            tabPage6 = new TabPage();
            pnlKhachHang = new Panel();
            dgvKhachHang = new DataGridView();
            panel25 = new Panel();
            btnSua_KH = new Button();
            btnThem_KH = new Button();
            txtTimKiem_KH = new TextBox();
            panel26 = new Panel();
            btnUser_KH = new Button();
            btnThoat_KH = new Button();
            lblUserName_KH = new Label();
            panel27 = new Panel();
            panel28 = new Panel();
            label10 = new Label();
            tabPage7 = new TabPage();
            pnlLichSu = new Panel();
            dgvLichSuCa = new DataGridView();
            panel7 = new Panel();
            button2 = new Button();
            dtpEndC_LSC = new DateTimePicker();
            label6 = new Label();
            dtpStart_LSC = new DateTimePicker();
            label15 = new Label();
            txtTimKiem_LSC = new TextBox();
            panel15 = new Panel();
            btnUser_LSC = new Button();
            btnThoat_LSC = new Button();
            lblUserName_LSC = new Label();
            panel16 = new Panel();
            panel17 = new Panel();
            label14 = new Label();
            panel29 = new Panel();
            panel30 = new Panel();
            panel31 = new Panel();
            label11 = new Label();
            panel32 = new Panel();
            lblUserName_LS = new Label();
            btnThongBao_LS = new Button();
            btnThoat_LS = new Button();
            btnUser_LS = new Button();
            btnXuatExcel_LS = new Button();
            txtTimKiem_LS = new TextBox();
            label12 = new Label();
            dtpStart_LS = new DateTimePicker();
            label13 = new Label();
            dtpEnd_LS = new DateTimePicker();
            dgvLichSu = new DataGridView();
            panel1.SuspendLayout();
            tabPage2.SuspendLayout();
            pnlQuanLyBan.SuspendLayout();
            pnl_top_QuanLyban.SuspendLayout();
            panel4.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            panel14.SuspendLayout();
            tabPage1.SuspendLayout();
            pnlThucDon.SuspendLayout();
            pnlThongTinMon.SuspendLayout();
            panel2.SuspendLayout();
            panel5.SuspendLayout();
            pnlKhac.SuspendLayout();
            pnlBanh.SuspendLayout();
            pnlTra.SuspendLayout();
            pnlCoffe.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage6.SuspendLayout();
            pnlKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).BeginInit();
            panel25.SuspendLayout();
            panel26.SuspendLayout();
            panel27.SuspendLayout();
            tabPage7.SuspendLayout();
            pnlLichSu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLichSuCa).BeginInit();
            panel7.SuspendLayout();
            panel15.SuspendLayout();
            panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).BeginInit();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(102, 44, 33);
            panel3.BackgroundImage = Properties.Resources.LOGO_removebg_preview;
            panel3.BackgroundImageLayout = ImageLayout.Zoom;
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(250, 125);
            panel3.TabIndex = 0;
            // 
            // btnThucDon
            // 
            btnThucDon.BackColor = Color.FromArgb(102, 44, 33);
            btnThucDon.Cursor = Cursors.Hand;
            btnThucDon.FlatAppearance.BorderSize = 0;
            btnThucDon.FlatStyle = FlatStyle.Flat;
            btnThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThucDon.ForeColor = Color.White;
            btnThucDon.Image = Properties.Resources.bolw_white;
            btnThucDon.ImageAlign = ContentAlignment.MiddleLeft;
            btnThucDon.Location = new Point(45, 163);
            btnThucDon.Name = "btnThucDon";
            btnThucDon.Size = new Size(166, 51);
            btnThucDon.TabIndex = 1;
            btnThucDon.Text = "Thực Đơn";
            btnThucDon.TextAlign = ContentAlignment.MiddleRight;
            btnThucDon.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnThucDon.UseVisualStyleBackColor = false;
            btnThucDon.Click += btnThucDon_Click;
            // 
            // btnQuanLyBan
            // 
            btnQuanLyBan.BackColor = Color.FromArgb(102, 44, 33);
            btnQuanLyBan.Cursor = Cursors.Hand;
            btnQuanLyBan.FlatAppearance.BorderSize = 0;
            btnQuanLyBan.FlatStyle = FlatStyle.Flat;
            btnQuanLyBan.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnQuanLyBan.ForeColor = Color.White;
            btnQuanLyBan.Image = Properties.Resources.plus_white;
            btnQuanLyBan.ImageAlign = ContentAlignment.MiddleLeft;
            btnQuanLyBan.Location = new Point(45, 217);
            btnQuanLyBan.Name = "btnQuanLyBan";
            btnQuanLyBan.Size = new Size(166, 51);
            btnQuanLyBan.TabIndex = 1;
            btnQuanLyBan.Text = "Đặt Bàn";
            btnQuanLyBan.TextAlign = ContentAlignment.MiddleRight;
            btnQuanLyBan.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnQuanLyBan.UseVisualStyleBackColor = false;
            btnQuanLyBan.Click += btnQuanLyBan_Click;
            // 
            // btnKhachHang
            // 
            btnKhachHang.BackColor = Color.FromArgb(102, 44, 33);
            btnKhachHang.Cursor = Cursors.Hand;
            btnKhachHang.FlatAppearance.BorderSize = 0;
            btnKhachHang.FlatStyle = FlatStyle.Flat;
            btnKhachHang.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnKhachHang.ForeColor = Color.White;
            btnKhachHang.Image = Properties.Resources.group_white;
            btnKhachHang.ImageAlign = ContentAlignment.MiddleLeft;
            btnKhachHang.Location = new Point(45, 274);
            btnKhachHang.Name = "btnKhachHang";
            btnKhachHang.Size = new Size(166, 51);
            btnKhachHang.TabIndex = 1;
            btnKhachHang.Text = "Khách hàng";
            btnKhachHang.TextAlign = ContentAlignment.MiddleRight;
            btnKhachHang.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnKhachHang.UseVisualStyleBackColor = false;
            btnKhachHang.Click += btnKhachHang_Click;
            // 
            // btnLichSu
            // 
            btnLichSu.BackColor = Color.FromArgb(102, 44, 33);
            btnLichSu.Cursor = Cursors.Hand;
            btnLichSu.FlatAppearance.BorderSize = 0;
            btnLichSu.FlatStyle = FlatStyle.Flat;
            btnLichSu.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnLichSu.ForeColor = Color.White;
            btnLichSu.Image = Properties.Resources.history_white;
            btnLichSu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLichSu.Location = new Point(45, 331);
            btnLichSu.Name = "btnLichSu";
            btnLichSu.Size = new Size(166, 51);
            btnLichSu.TabIndex = 1;
            btnLichSu.Text = "Hoá Đơn";
            btnLichSu.TextAlign = ContentAlignment.MiddleRight;
            btnLichSu.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnLichSu.UseVisualStyleBackColor = false;
            btnLichSu.Click += btnLichSu_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(102, 44, 33);
            panel1.Controls.Add(btnLichSu);
            panel1.Controls.Add(btnKhachHang);
            panel1.Controls.Add(btnQuanLyBan);
            panel1.Controls.Add(btnThucDon);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 673);
            panel1.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(pnlQuanLyBan);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1004, 640);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "tabPage2";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlQuanLyBan
            // 
            pnlQuanLyBan.Controls.Add(flpQuanLyBan);
            pnlQuanLyBan.Controls.Add(pnl_top_QuanLyban);
            pnlQuanLyBan.Dock = DockStyle.Fill;
            pnlQuanLyBan.Location = new Point(3, 3);
            pnlQuanLyBan.Name = "pnlQuanLyBan";
            pnlQuanLyBan.Size = new Size(998, 634);
            pnlQuanLyBan.TabIndex = 2;
            pnlQuanLyBan.Visible = false;
            // 
            // flpQuanLyBan
            // 
            flpQuanLyBan.AutoScroll = true;
            flpQuanLyBan.BackColor = Color.White;
            flpQuanLyBan.Dock = DockStyle.Fill;
            flpQuanLyBan.Location = new Point(0, 125);
            flpQuanLyBan.Name = "flpQuanLyBan";
            flpQuanLyBan.Size = new Size(998, 509);
            flpQuanLyBan.TabIndex = 2;
            // 
            // pnl_top_QuanLyban
            // 
            pnl_top_QuanLyban.BackColor = Color.FromArgb(217, 186, 166);
            pnl_top_QuanLyban.Controls.Add(label5);
            pnl_top_QuanLyban.Controls.Add(label4);
            pnl_top_QuanLyban.Controls.Add(panel9);
            pnl_top_QuanLyban.Controls.Add(panel8);
            pnl_top_QuanLyban.Controls.Add(cboLoai);
            pnl_top_QuanLyban.Controls.Add(cboTrangThai);
            pnl_top_QuanLyban.Controls.Add(panel4);
            pnl_top_QuanLyban.Dock = DockStyle.Top;
            pnl_top_QuanLyban.Location = new Point(0, 0);
            pnl_top_QuanLyban.Name = "pnl_top_QuanLyban";
            pnl_top_QuanLyban.Size = new Size(998, 125);
            pnl_top_QuanLyban.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.Location = new Point(594, 81);
            label5.Name = "label5";
            label5.Size = new Size(131, 25);
            label5.TabIndex = 5;
            label5.Text = "Đang sử dụng";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(470, 81);
            label4.Name = "label4";
            label4.Size = new Size(62, 25);
            label4.TabIndex = 5;
            label4.Text = "Trống";
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(254, 142, 142);
            panel9.Location = new Point(548, 81);
            panel9.Name = "panel9";
            panel9.Size = new Size(40, 27);
            panel9.TabIndex = 4;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(0, 203, 206);
            panel8.Location = new Point(424, 81);
            panel8.Name = "panel8";
            panel8.Size = new Size(40, 27);
            panel8.TabIndex = 4;
            // 
            // cboLoai
            // 
            cboLoai.FlatStyle = FlatStyle.Popup;
            cboLoai.FormattingEnabled = true;
            cboLoai.Items.AddRange(new object[] { "Phăng", "Lỗ" });
            cboLoai.Location = new Point(775, 80);
            cboLoai.Name = "cboLoai";
            cboLoai.Size = new Size(80, 28);
            cboLoai.TabIndex = 3;
            cboLoai.Text = "Loại";
            cboLoai.SelectedIndexChanged += cboLoai_SelectedIndexChanged;
            // 
            // cboTrangThai
            // 
            cboTrangThai.FlatStyle = FlatStyle.Popup;
            cboTrangThai.FormattingEnabled = true;
            cboTrangThai.Items.AddRange(new object[] { "Trống", "Đang Sử Dụng" });
            cboTrangThai.Location = new Point(871, 80);
            cboTrangThai.Name = "cboTrangThai";
            cboTrangThai.Size = new Size(95, 28);
            cboTrangThai.TabIndex = 3;
            cboTrangThai.Text = "Trạng thái";
            cboTrangThai.SelectedIndexChanged += cboTrangThai_SelectedIndexChanged;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(255, 241, 230);
            panel4.Controls.Add(btnUser_Ban);
            panel4.Controls.Add(btnThoat_Ban);
            panel4.Controls.Add(lblUserName_Ban);
            panel4.Controls.Add(panel14);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(998, 62);
            panel4.TabIndex = 0;
            // 
            // btnUser_Ban
            // 
            btnUser_Ban.AutoSize = true;
            btnUser_Ban.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_Ban.BackgroundImage = Properties.Resources.login;
            btnUser_Ban.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_Ban.ContextMenuStrip = contextMenuStrip1;
            btnUser_Ban.Cursor = Cursors.Hand;
            btnUser_Ban.FlatAppearance.BorderSize = 0;
            btnUser_Ban.FlatStyle = FlatStyle.Flat;
            btnUser_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_Ban.ForeColor = Color.White;
            btnUser_Ban.Location = new Point(871, 10);
            btnUser_Ban.Name = "btnUser_Ban";
            btnUser_Ban.Size = new Size(66, 42);
            btnUser_Ban.TabIndex = 1;
            btnUser_Ban.UseVisualStyleBackColor = false;
            btnUser_Ban.Click += btnUser_Ban_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { xemThôngTinToolStripMenuItem, đổiMậtKhẩuToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(173, 52);
            // 
            // xemThôngTinToolStripMenuItem
            // 
            xemThôngTinToolStripMenuItem.Name = "xemThôngTinToolStripMenuItem";
            xemThôngTinToolStripMenuItem.Size = new Size(172, 24);
            xemThôngTinToolStripMenuItem.Text = "Xem thông tin";
            xemThôngTinToolStripMenuItem.Click += xemThôngTinToolStripMenuItem_Click;
            // 
            // đổiMậtKhẩuToolStripMenuItem
            // 
            đổiMậtKhẩuToolStripMenuItem.Name = "đổiMậtKhẩuToolStripMenuItem";
            đổiMậtKhẩuToolStripMenuItem.Size = new Size(172, 24);
            đổiMậtKhẩuToolStripMenuItem.Text = "Đổi mật khẩu";
            đổiMậtKhẩuToolStripMenuItem.Click += đổiMậtKhẩuToolStripMenuItem_Click;
            // 
            // btnThoat_Ban
            // 
            btnThoat_Ban.AutoSize = true;
            btnThoat_Ban.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_Ban.BackgroundImage = Properties.Resources.exit;
            btnThoat_Ban.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_Ban.Cursor = Cursors.Hand;
            btnThoat_Ban.FlatAppearance.BorderSize = 0;
            btnThoat_Ban.FlatStyle = FlatStyle.Flat;
            btnThoat_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_Ban.ForeColor = Color.White;
            btnThoat_Ban.Location = new Point(934, 8);
            btnThoat_Ban.Name = "btnThoat_Ban";
            btnThoat_Ban.Size = new Size(66, 46);
            btnThoat_Ban.TabIndex = 1;
            btnThoat_Ban.UseVisualStyleBackColor = false;
            btnThoat_Ban.Click += btnThoat_Ban_Click;
            // 
            // lblUserName_Ban
            // 
            lblUserName_Ban.AutoSize = true;
            lblUserName_Ban.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_Ban.Location = new Point(735, 20);
            lblUserName_Ban.Name = "lblUserName_Ban";
            lblUserName_Ban.Size = new Size(119, 26);
            lblUserName_Ban.TabIndex = 2;
            lblUserName_Ban.Text = "user name";
            // 
            // panel14
            // 
            panel14.Controls.Add(panel13);
            panel14.Controls.Add(label1);
            panel14.Location = new Point(6, 3);
            panel14.Name = "panel14";
            panel14.Size = new Size(403, 51);
            panel14.TabIndex = 3;
            // 
            // panel13
            // 
            panel13.BackgroundImage = Properties.Resources.plus_black;
            panel13.BackgroundImageLayout = ImageLayout.Zoom;
            panel13.Location = new Point(12, 3);
            panel13.Name = "panel13";
            panel13.Size = new Size(74, 45);
            panel13.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.Location = new Point(83, 15);
            label1.Name = "label1";
            label1.Size = new Size(160, 44);
            label1.TabIndex = 2;
            label1.Text = "Đặt Bàn";
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(pnlThucDon);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1004, 640);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "tabPage1";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnlThucDon
            // 
            pnlThucDon.BackColor = Color.Transparent;
            pnlThucDon.Controls.Add(pnlThongTinMon);
            pnlThucDon.Controls.Add(fplThucDon);
            pnlThucDon.Controls.Add(panel5);
            pnlThucDon.Dock = DockStyle.Fill;
            pnlThucDon.Location = new Point(3, 3);
            pnlThucDon.Name = "pnlThucDon";
            pnlThucDon.Size = new Size(998, 634);
            pnlThucDon.TabIndex = 3;
            pnlThucDon.Visible = false;
            // 
            // pnlThongTinMon
            // 
            pnlThongTinMon.Controls.Add(label9);
            pnlThongTinMon.Controls.Add(panel2);
            pnlThongTinMon.Controls.Add(btnGui);
            pnlThongTinMon.Controls.Add(fplChiTietHoaDon);
            pnlThongTinMon.Controls.Add(btnHuy);
            pnlThongTinMon.Controls.Add(lblTongTien);
            pnlThongTinMon.Location = new Point(525, 125);
            pnlThongTinMon.Name = "pnlThongTinMon";
            pnlThongTinMon.Size = new Size(475, 491);
            pnlThongTinMon.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            label9.Location = new Point(217, 381);
            label9.Name = "label9";
            label9.Size = new Size(94, 25);
            label9.TabIndex = 10;
            label9.Text = "Tổng tiền";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(217, 186, 166);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(-4, 7);
            panel2.Name = "panel2";
            panel2.Size = new Size(477, 37);
            panel2.TabIndex = 9;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            label8.Location = new Point(328, 9);
            label8.Name = "label8";
            label8.Size = new Size(102, 21);
            label8.TabIndex = 0;
            label8.Text = "Thành tiền";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            label3.Location = new Point(184, 7);
            label3.Name = "label3";
            label3.Size = new Size(91, 21);
            label3.TabIndex = 0;
            label3.Text = "Số lượng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            label2.Location = new Point(10, 9);
            label2.Name = "label2";
            label2.Size = new Size(86, 21);
            label2.TabIndex = 0;
            label2.Text = "Tên món";
            // 
            // btnGui
            // 
            btnGui.AutoSize = true;
            btnGui.BackColor = Color.White;
            btnGui.Cursor = Cursors.Hand;
            btnGui.FlatAppearance.BorderSize = 0;
            btnGui.FlatStyle = FlatStyle.Popup;
            btnGui.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnGui.ForeColor = Color.FromArgb(102, 44, 33);
            btnGui.Location = new Point(251, 438);
            btnGui.Name = "btnGui";
            btnGui.Size = new Size(80, 42);
            btnGui.TabIndex = 5;
            btnGui.Text = "Gửi";
            btnGui.UseVisualStyleBackColor = false;
            btnGui.Click += btnGui_Click;
            // 
            // fplChiTietHoaDon
            // 
            fplChiTietHoaDon.AutoScroll = true;
            fplChiTietHoaDon.BackColor = Color.FromArgb(235, 228, 226);
            fplChiTietHoaDon.BorderStyle = BorderStyle.Fixed3D;
            fplChiTietHoaDon.Location = new Point(-4, 40);
            fplChiTietHoaDon.Name = "fplChiTietHoaDon";
            fplChiTietHoaDon.Size = new Size(484, 316);
            fplChiTietHoaDon.TabIndex = 8;
            // 
            // btnHuy
            // 
            btnHuy.AutoSize = true;
            btnHuy.BackColor = Color.White;
            btnHuy.Cursor = Cursors.Hand;
            btnHuy.FlatAppearance.BorderSize = 0;
            btnHuy.FlatStyle = FlatStyle.Popup;
            btnHuy.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnHuy.ForeColor = Color.FromArgb(102, 44, 33);
            btnHuy.Location = new Point(346, 438);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(80, 42);
            btnHuy.TabIndex = 4;
            btnHuy.Text = "Huỷ";
            btnHuy.UseVisualStyleBackColor = false;
            btnHuy.Click += btnHuy_Click;
            // 
            // lblTongTien
            // 
            lblTongTien.AutoSize = true;
            lblTongTien.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            lblTongTien.Location = new Point(330, 381);
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Size = new Size(59, 25);
            lblTongTien.TabIndex = 7;
            lblTongTien.Text = "0 vnd";
            // 
            // fplThucDon
            // 
            fplThucDon.AutoScroll = true;
            fplThucDon.Location = new Point(0, 125);
            fplThucDon.Name = "fplThucDon";
            fplThucDon.Size = new Size(519, 509);
            fplThucDon.TabIndex = 4;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(217, 186, 166);
            panel5.Controls.Add(cboBan);
            panel5.Controls.Add(pnlKhac);
            panel5.Controls.Add(pnlBanh);
            panel5.Controls.Add(pnlTra);
            panel5.Controls.Add(pnlCoffe);
            panel5.Controls.Add(btnKhac);
            panel5.Controls.Add(btnBanh);
            panel5.Controls.Add(btnTra);
            panel5.Controls.Add(btnCoffe);
            panel5.Controls.Add(txtTimKiem_ThucDon);
            panel5.Controls.Add(panel10);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(998, 125);
            panel5.TabIndex = 1;
            // 
            // cboBan
            // 
            cboBan.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            cboBan.FormattingEnabled = true;
            cboBan.Location = new Point(871, 79);
            cboBan.Name = "cboBan";
            cboBan.Size = new Size(80, 33);
            cboBan.TabIndex = 10;
            cboBan.Text = "Bàn";
            cboBan.SelectedIndexChanged += cboBan_SelectedIndexChanged;
            // 
            // pnlKhac
            // 
            pnlKhac.BackColor = Color.FromArgb(102, 44, 33);
            pnlKhac.Controls.Add(flowLayoutPanel4);
            pnlKhac.Location = new Point(385, 114);
            pnlKhac.Name = "pnlKhac";
            pnlKhac.Size = new Size(130, 11);
            pnlKhac.TabIndex = 9;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Location = new Point(73, 4);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(8, 8);
            flowLayoutPanel4.TabIndex = 0;
            // 
            // pnlBanh
            // 
            pnlBanh.BackColor = Color.FromArgb(102, 44, 33);
            pnlBanh.Controls.Add(flowLayoutPanel3);
            pnlBanh.Location = new Point(259, 114);
            pnlBanh.Name = "pnlBanh";
            pnlBanh.Size = new Size(130, 11);
            pnlBanh.TabIndex = 9;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Location = new Point(73, 4);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(8, 8);
            flowLayoutPanel3.TabIndex = 0;
            // 
            // pnlTra
            // 
            pnlTra.BackColor = Color.FromArgb(102, 44, 33);
            pnlTra.Controls.Add(flowLayoutPanel2);
            pnlTra.Location = new Point(129, 114);
            pnlTra.Name = "pnlTra";
            pnlTra.Size = new Size(130, 11);
            pnlTra.TabIndex = 9;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Location = new Point(73, 4);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(8, 8);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // pnlCoffe
            // 
            pnlCoffe.BackColor = Color.FromArgb(102, 44, 33);
            pnlCoffe.Controls.Add(flowLayoutPanel1);
            pnlCoffe.Location = new Point(3, 114);
            pnlCoffe.Name = "pnlCoffe";
            pnlCoffe.Size = new Size(130, 11);
            pnlCoffe.TabIndex = 9;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Location = new Point(73, 4);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(8, 8);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // btnKhac
            // 
            btnKhac.BackColor = Color.White;
            btnKhac.Cursor = Cursors.Hand;
            btnKhac.FlatAppearance.BorderSize = 0;
            btnKhac.FlatStyle = FlatStyle.Flat;
            btnKhac.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnKhac.ForeColor = Color.Black;
            btnKhac.Location = new Point(385, 72);
            btnKhac.Name = "btnKhac";
            btnKhac.Size = new Size(130, 40);
            btnKhac.TabIndex = 1;
            btnKhac.Text = "Rượu Bia";
            btnKhac.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnKhac.UseVisualStyleBackColor = false;
            btnKhac.Click += btnKhac_Click;
            // 
            // btnBanh
            // 
            btnBanh.BackColor = Color.White;
            btnBanh.Cursor = Cursors.Hand;
            btnBanh.FlatAppearance.BorderSize = 0;
            btnBanh.FlatStyle = FlatStyle.Flat;
            btnBanh.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnBanh.ForeColor = Color.Black;
            btnBanh.Location = new Point(259, 72);
            btnBanh.Name = "btnBanh";
            btnBanh.Size = new Size(130, 40);
            btnBanh.TabIndex = 1;
            btnBanh.Text = "Thuốc Lá";
            btnBanh.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnBanh.UseVisualStyleBackColor = false;
            btnBanh.Click += btnBanh_Click;
            // 
            // btnTra
            // 
            btnTra.BackColor = Color.White;
            btnTra.Cursor = Cursors.Hand;
            btnTra.FlatAppearance.BorderSize = 0;
            btnTra.FlatStyle = FlatStyle.Flat;
            btnTra.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnTra.ForeColor = Color.Black;
            btnTra.Location = new Point(132, 72);
            btnTra.Name = "btnTra";
            btnTra.Size = new Size(130, 40);
            btnTra.TabIndex = 1;
            btnTra.Text = "Đồ Uống";
            btnTra.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnTra.UseVisualStyleBackColor = false;
            btnTra.Click += btnTra_Click;
            // 
            // btnCoffe
            // 
            btnCoffe.BackColor = Color.White;
            btnCoffe.Cursor = Cursors.Hand;
            btnCoffe.FlatAppearance.BorderSize = 0;
            btnCoffe.FlatStyle = FlatStyle.Flat;
            btnCoffe.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnCoffe.ForeColor = Color.Black;
            btnCoffe.Location = new Point(6, 72);
            btnCoffe.Name = "btnCoffe";
            btnCoffe.Size = new Size(130, 40);
            btnCoffe.TabIndex = 1;
            btnCoffe.Text = "Đồ Ăn";
            btnCoffe.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCoffe.UseVisualStyleBackColor = false;
            btnCoffe.Click += btnCoffe_Click;
            // 
            // txtTimKiem_ThucDon
            // 
            txtTimKiem_ThucDon.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_ThucDon.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_ThucDon.Location = new Point(557, 79);
            txtTimKiem_ThucDon.Multiline = true;
            txtTimKiem_ThucDon.Name = "txtTimKiem_ThucDon";
            txtTimKiem_ThucDon.Size = new Size(279, 33);
            txtTimKiem_ThucDon.TabIndex = 7;
            txtTimKiem_ThucDon.Text = "Tìm kiếm...";
            txtTimKiem_ThucDon.TextChanged += txtTimKiem_ThucDon_TextChanged;
            txtTimKiem_ThucDon.Enter += txtTimKiem_ThucDon_Enter;
            txtTimKiem_ThucDon.Leave += txtTimKiem_ThucDon_Leave;
            // 
            // panel10
            // 
            panel10.BackColor = Color.FromArgb(255, 241, 230);
            panel10.Controls.Add(btnUser_ThucDon);
            panel10.Controls.Add(btnThoat_ThucDon);
            panel10.Controls.Add(lblUsername_TD);
            panel10.Controls.Add(panel11);
            panel10.Dock = DockStyle.Top;
            panel10.Location = new Point(0, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(998, 62);
            panel10.TabIndex = 0;
            // 
            // btnUser_ThucDon
            // 
            btnUser_ThucDon.AutoSize = true;
            btnUser_ThucDon.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_ThucDon.BackgroundImage = Properties.Resources.login;
            btnUser_ThucDon.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_ThucDon.ContextMenuStrip = contextMenuStrip1;
            btnUser_ThucDon.Cursor = Cursors.Hand;
            btnUser_ThucDon.FlatAppearance.BorderSize = 0;
            btnUser_ThucDon.FlatStyle = FlatStyle.Flat;
            btnUser_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_ThucDon.ForeColor = Color.White;
            btnUser_ThucDon.Location = new Point(871, 10);
            btnUser_ThucDon.Name = "btnUser_ThucDon";
            btnUser_ThucDon.Size = new Size(66, 42);
            btnUser_ThucDon.TabIndex = 1;
            btnUser_ThucDon.UseVisualStyleBackColor = false;
            btnUser_ThucDon.Click += btnUser_ThucDon_Click;
            // 
            // btnThoat_ThucDon
            // 
            btnThoat_ThucDon.AutoSize = true;
            btnThoat_ThucDon.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_ThucDon.BackgroundImage = Properties.Resources.exit;
            btnThoat_ThucDon.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_ThucDon.Cursor = Cursors.Hand;
            btnThoat_ThucDon.FlatAppearance.BorderSize = 0;
            btnThoat_ThucDon.FlatStyle = FlatStyle.Flat;
            btnThoat_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_ThucDon.ForeColor = Color.White;
            btnThoat_ThucDon.Location = new Point(934, 8);
            btnThoat_ThucDon.Name = "btnThoat_ThucDon";
            btnThoat_ThucDon.Size = new Size(66, 46);
            btnThoat_ThucDon.TabIndex = 1;
            btnThoat_ThucDon.UseVisualStyleBackColor = false;
            btnThoat_ThucDon.Click += btnThoat_ThucDon_Click;
            // 
            // lblUsername_TD
            // 
            lblUsername_TD.AutoSize = true;
            lblUsername_TD.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUsername_TD.Location = new Point(735, 20);
            lblUsername_TD.Name = "lblUsername_TD";
            lblUsername_TD.Size = new Size(119, 26);
            lblUsername_TD.TabIndex = 2;
            lblUsername_TD.Text = "user name";
            // 
            // panel11
            // 
            panel11.Controls.Add(panel12);
            panel11.Controls.Add(label7);
            panel11.Location = new Point(6, 3);
            panel11.Name = "panel11";
            panel11.Size = new Size(403, 51);
            panel11.TabIndex = 3;
            // 
            // panel12
            // 
            panel12.BackgroundImage = Properties.Resources.bolw_black;
            panel12.BackgroundImageLayout = ImageLayout.Zoom;
            panel12.Location = new Point(12, 3);
            panel12.Name = "panel12";
            panel12.Size = new Size(74, 45);
            panel12.TabIndex = 0;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(83, 15);
            label7.Name = "label7";
            label7.Size = new Size(199, 44);
            label7.TabIndex = 2;
            label7.Text = "Thực Đơn";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(250, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1012, 673);
            tabControl1.TabIndex = 3;
            tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(pnlKhachHang);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(1004, 640);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "tabPage6";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // pnlKhachHang
            // 
            pnlKhachHang.Controls.Add(dgvKhachHang);
            pnlKhachHang.Controls.Add(panel25);
            pnlKhachHang.Dock = DockStyle.Fill;
            pnlKhachHang.Location = new Point(3, 3);
            pnlKhachHang.Name = "pnlKhachHang";
            pnlKhachHang.Size = new Size(998, 634);
            pnlKhachHang.TabIndex = 5;
            pnlKhachHang.Visible = false;
            // 
            // dgvKhachHang
            // 
            dgvKhachHang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvKhachHang.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvKhachHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvKhachHang.Dock = DockStyle.Fill;
            dgvKhachHang.Location = new Point(0, 125);
            dgvKhachHang.Name = "dgvKhachHang";
            dgvKhachHang.RowHeadersWidth = 51;
            dgvKhachHang.Size = new Size(998, 509);
            dgvKhachHang.TabIndex = 3;
            // 
            // panel25
            // 
            panel25.BackColor = Color.FromArgb(217, 186, 166);
            panel25.Controls.Add(btnSua_KH);
            panel25.Controls.Add(btnThem_KH);
            panel25.Controls.Add(txtTimKiem_KH);
            panel25.Controls.Add(panel26);
            panel25.Dock = DockStyle.Top;
            panel25.Location = new Point(0, 0);
            panel25.Name = "panel25";
            panel25.Size = new Size(998, 125);
            panel25.TabIndex = 1;
            // 
            // btnSua_KH
            // 
            btnSua_KH.AutoSize = true;
            btnSua_KH.BackColor = Color.White;
            btnSua_KH.Cursor = Cursors.Hand;
            btnSua_KH.FlatAppearance.BorderSize = 0;
            btnSua_KH.FlatStyle = FlatStyle.Popup;
            btnSua_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_KH.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_KH.Location = new Point(121, 73);
            btnSua_KH.Name = "btnSua_KH";
            btnSua_KH.Size = new Size(80, 42);
            btnSua_KH.TabIndex = 9;
            btnSua_KH.Text = "Sửa";
            btnSua_KH.UseVisualStyleBackColor = false;
            btnSua_KH.Click += btnSua_KH_Click;
            // 
            // btnThem_KH
            // 
            btnThem_KH.AutoSize = true;
            btnThem_KH.BackColor = Color.White;
            btnThem_KH.Cursor = Cursors.Hand;
            btnThem_KH.FlatAppearance.BorderSize = 0;
            btnThem_KH.FlatStyle = FlatStyle.Popup;
            btnThem_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_KH.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_KH.Location = new Point(18, 73);
            btnThem_KH.Name = "btnThem_KH";
            btnThem_KH.Size = new Size(80, 42);
            btnThem_KH.TabIndex = 10;
            btnThem_KH.Text = "Thêm";
            btnThem_KH.UseVisualStyleBackColor = false;
            btnThem_KH.Click += btnThem_KH_Click;
            // 
            // txtTimKiem_KH
            // 
            txtTimKiem_KH.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_KH.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_KH.Location = new Point(682, 81);
            txtTimKiem_KH.Multiline = true;
            txtTimKiem_KH.Name = "txtTimKiem_KH";
            txtTimKiem_KH.Size = new Size(255, 27);
            txtTimKiem_KH.TabIndex = 8;
            txtTimKiem_KH.Text = "Tìm kiếm...";
            txtTimKiem_KH.TextChanged += txtTimKiem_KH_TextChanged;
            txtTimKiem_KH.Enter += txtTimKiem_KH_Enter;
            txtTimKiem_KH.Leave += txtTimKiem_KH_Leave;
            // 
            // panel26
            // 
            panel26.BackColor = Color.FromArgb(255, 241, 230);
            panel26.Controls.Add(btnUser_KH);
            panel26.Controls.Add(btnThoat_KH);
            panel26.Controls.Add(lblUserName_KH);
            panel26.Controls.Add(panel27);
            panel26.Dock = DockStyle.Top;
            panel26.Location = new Point(0, 0);
            panel26.Name = "panel26";
            panel26.Size = new Size(998, 62);
            panel26.TabIndex = 0;
            // 
            // btnUser_KH
            // 
            btnUser_KH.AutoSize = true;
            btnUser_KH.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_KH.BackgroundImage = Properties.Resources.login;
            btnUser_KH.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_KH.ContextMenuStrip = contextMenuStrip1;
            btnUser_KH.Cursor = Cursors.Hand;
            btnUser_KH.FlatAppearance.BorderSize = 0;
            btnUser_KH.FlatStyle = FlatStyle.Flat;
            btnUser_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_KH.ForeColor = Color.White;
            btnUser_KH.Location = new Point(871, 10);
            btnUser_KH.Name = "btnUser_KH";
            btnUser_KH.Size = new Size(66, 42);
            btnUser_KH.TabIndex = 1;
            btnUser_KH.UseVisualStyleBackColor = false;
            btnUser_KH.Click += btnUser_KH_Click;
            // 
            // btnThoat_KH
            // 
            btnThoat_KH.AutoSize = true;
            btnThoat_KH.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_KH.BackgroundImage = Properties.Resources.exit;
            btnThoat_KH.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_KH.Cursor = Cursors.Hand;
            btnThoat_KH.FlatAppearance.BorderSize = 0;
            btnThoat_KH.FlatStyle = FlatStyle.Flat;
            btnThoat_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_KH.ForeColor = Color.White;
            btnThoat_KH.Location = new Point(934, 8);
            btnThoat_KH.Name = "btnThoat_KH";
            btnThoat_KH.Size = new Size(66, 46);
            btnThoat_KH.TabIndex = 1;
            btnThoat_KH.UseVisualStyleBackColor = false;
            btnThoat_KH.Click += btnThoat_KH_Click;
            // 
            // lblUserName_KH
            // 
            lblUserName_KH.AutoSize = true;
            lblUserName_KH.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_KH.Location = new Point(735, 20);
            lblUserName_KH.Name = "lblUserName_KH";
            lblUserName_KH.Size = new Size(119, 26);
            lblUserName_KH.TabIndex = 2;
            lblUserName_KH.Text = "user name";
            // 
            // panel27
            // 
            panel27.Controls.Add(panel28);
            panel27.Controls.Add(label10);
            panel27.Location = new Point(6, 3);
            panel27.Name = "panel27";
            panel27.Size = new Size(403, 51);
            panel27.TabIndex = 3;
            // 
            // panel28
            // 
            panel28.BackgroundImage = Properties.Resources.group_black;
            panel28.BackgroundImageLayout = ImageLayout.Zoom;
            panel28.Location = new Point(12, 3);
            panel28.Name = "panel28";
            panel28.Size = new Size(74, 45);
            panel28.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label10.Location = new Point(83, 15);
            label10.Name = "label10";
            label10.Size = new Size(238, 44);
            label10.TabIndex = 2;
            label10.Text = "Khách Hàng";
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(pnlLichSu);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(1004, 640);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "tabPage7";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // pnlLichSu
            // 
            pnlLichSu.Controls.Add(dgvLichSuCa);
            pnlLichSu.Controls.Add(panel7);
            pnlLichSu.Dock = DockStyle.Fill;
            pnlLichSu.Location = new Point(3, 3);
            pnlLichSu.Name = "pnlLichSu";
            pnlLichSu.Size = new Size(998, 634);
            pnlLichSu.TabIndex = 6;
            pnlLichSu.Visible = false;
            // 
            // dgvLichSuCa
            // 
            dgvLichSuCa.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLichSuCa.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvLichSuCa.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLichSuCa.Dock = DockStyle.Fill;
            dgvLichSuCa.Location = new Point(0, 125);
            dgvLichSuCa.Name = "dgvLichSuCa";
            dgvLichSuCa.RowHeadersWidth = 51;
            dgvLichSuCa.Size = new Size(998, 509);
            dgvLichSuCa.TabIndex = 3;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(217, 186, 166);
            panel7.Controls.Add(button2);
            panel7.Controls.Add(dtpEndC_LSC);
            panel7.Controls.Add(label6);
            panel7.Controls.Add(dtpStart_LSC);
            panel7.Controls.Add(label15);
            panel7.Controls.Add(txtTimKiem_LSC);
            panel7.Controls.Add(panel15);
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(998, 125);
            panel7.TabIndex = 1;
            // 
            // button2
            // 
            button2.AutoSize = true;
            button2.BackColor = Color.White;
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button2.ForeColor = Color.FromArgb(102, 44, 33);
            button2.Image = Properties.Resources.excel1;
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(849, 70);
            button2.Name = "button2";
            button2.Size = new Size(144, 42);
            button2.TabIndex = 14;
            button2.Text = "Xuất Excel";
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // dtpEndC_LSC
            // 
            dtpEndC_LSC.Format = DateTimePickerFormat.Short;
            dtpEndC_LSC.Location = new Point(329, 78);
            dtpEndC_LSC.Name = "dtpEndC_LSC";
            dtpEndC_LSC.Size = new Size(99, 27);
            dtpEndC_LSC.TabIndex = 12;
            dtpEndC_LSC.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label6.Location = new Point(227, 81);
            label6.Name = "label6";
            label6.Size = new Size(100, 21);
            label6.TabIndex = 10;
            label6.Text = "Đến ngày:";
            // 
            // dtpStart_LSC
            // 
            dtpStart_LSC.Format = DateTimePickerFormat.Short;
            dtpStart_LSC.Location = new Point(120, 78);
            dtpStart_LSC.Name = "dtpStart_LSC";
            dtpStart_LSC.Size = new Size(101, 27);
            dtpStart_LSC.TabIndex = 13;
            dtpStart_LSC.ValueChanged += dateTimePicker2_ValueChanged;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label15.Location = new Point(18, 81);
            label15.Name = "label15";
            label15.Size = new Size(89, 21);
            label15.TabIndex = 11;
            label15.Text = "Từ ngày:";
            // 
            // txtTimKiem_LSC
            // 
            txtTimKiem_LSC.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_LSC.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_LSC.Location = new Point(571, 81);
            txtTimKiem_LSC.Multiline = true;
            txtTimKiem_LSC.Name = "txtTimKiem_LSC";
            txtTimKiem_LSC.Size = new Size(255, 27);
            txtTimKiem_LSC.TabIndex = 8;
            txtTimKiem_LSC.Text = "Tìm kiếm...";
            txtTimKiem_LSC.TextChanged += txtTimKiem_LSC_TextChanged;
            txtTimKiem_LSC.Enter += txtTimKiem_LSC_Enter;
            txtTimKiem_LSC.Leave += txtTimKiem_LSC_Leave;
            // 
            // panel15
            // 
            panel15.BackColor = Color.FromArgb(255, 241, 230);
            panel15.Controls.Add(btnUser_LSC);
            panel15.Controls.Add(btnThoat_LSC);
            panel15.Controls.Add(lblUserName_LSC);
            panel15.Controls.Add(panel16);
            panel15.Dock = DockStyle.Top;
            panel15.Location = new Point(0, 0);
            panel15.Name = "panel15";
            panel15.Size = new Size(998, 62);
            panel15.TabIndex = 0;
            // 
            // btnUser_LSC
            // 
            btnUser_LSC.AutoSize = true;
            btnUser_LSC.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_LSC.BackgroundImage = Properties.Resources.login;
            btnUser_LSC.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_LSC.ContextMenuStrip = contextMenuStrip1;
            btnUser_LSC.Cursor = Cursors.Hand;
            btnUser_LSC.FlatAppearance.BorderSize = 0;
            btnUser_LSC.FlatStyle = FlatStyle.Flat;
            btnUser_LSC.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_LSC.ForeColor = Color.White;
            btnUser_LSC.Location = new Point(871, 10);
            btnUser_LSC.Name = "btnUser_LSC";
            btnUser_LSC.Size = new Size(66, 42);
            btnUser_LSC.TabIndex = 1;
            btnUser_LSC.UseVisualStyleBackColor = false;
            btnUser_LSC.Click += btnUser_LSC_Click;
            // 
            // btnThoat_LSC
            // 
            btnThoat_LSC.AutoSize = true;
            btnThoat_LSC.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_LSC.BackgroundImage = Properties.Resources.exit;
            btnThoat_LSC.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_LSC.Cursor = Cursors.Hand;
            btnThoat_LSC.FlatAppearance.BorderSize = 0;
            btnThoat_LSC.FlatStyle = FlatStyle.Flat;
            btnThoat_LSC.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_LSC.ForeColor = Color.White;
            btnThoat_LSC.Location = new Point(934, 8);
            btnThoat_LSC.Name = "btnThoat_LSC";
            btnThoat_LSC.Size = new Size(66, 46);
            btnThoat_LSC.TabIndex = 1;
            btnThoat_LSC.UseVisualStyleBackColor = false;
            btnThoat_LSC.Click += btnThoat_LSC_Click;
            // 
            // lblUserName_LSC
            // 
            lblUserName_LSC.AutoSize = true;
            lblUserName_LSC.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_LSC.Location = new Point(735, 20);
            lblUserName_LSC.Name = "lblUserName_LSC";
            lblUserName_LSC.Size = new Size(119, 26);
            lblUserName_LSC.TabIndex = 2;
            lblUserName_LSC.Text = "user name";
            // 
            // panel16
            // 
            panel16.Controls.Add(panel17);
            panel16.Controls.Add(label14);
            panel16.Location = new Point(6, 3);
            panel16.Name = "panel16";
            panel16.Size = new Size(403, 51);
            panel16.TabIndex = 3;
            // 
            // panel17
            // 
            panel17.BackgroundImage = Properties.Resources.history_black;
            panel17.BackgroundImageLayout = ImageLayout.Zoom;
            panel17.Location = new Point(12, 3);
            panel17.Name = "panel17";
            panel17.Size = new Size(74, 45);
            panel17.TabIndex = 0;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label14.Location = new Point(83, 15);
            label14.Name = "label14";
            label14.Size = new Size(176, 44);
            label14.TabIndex = 2;
            label14.Text = "Hoá Đơn";
            // 
            // panel29
            // 
            panel29.BackColor = Color.FromArgb(217, 186, 166);
            panel29.Dock = DockStyle.Top;
            panel29.Location = new Point(0, 0);
            panel29.Name = "panel29";
            panel29.Size = new Size(998, 125);
            panel29.TabIndex = 1;
            // 
            // panel30
            // 
            panel30.BackColor = Color.FromArgb(255, 241, 230);
            panel30.Dock = DockStyle.Top;
            panel30.Location = new Point(0, 0);
            panel30.Name = "panel30";
            panel30.Size = new Size(998, 62);
            panel30.TabIndex = 0;
            // 
            // panel31
            // 
            panel31.Location = new Point(6, 3);
            panel31.Name = "panel31";
            panel31.Size = new Size(403, 51);
            panel31.TabIndex = 3;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label11.Location = new Point(102, 3);
            label11.Name = "label11";
            label11.Size = new Size(158, 44);
            label11.TabIndex = 2;
            // 
            // panel32
            // 
            panel32.BackgroundImage = Properties.Resources.history_black;
            panel32.BackgroundImageLayout = ImageLayout.Zoom;
            panel32.Location = new Point(12, 3);
            panel32.Name = "panel32";
            panel32.Size = new Size(74, 45);
            panel32.TabIndex = 0;
            // 
            // lblUserName_LS
            // 
            lblUserName_LS.AutoSize = true;
            lblUserName_LS.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_LS.Location = new Point(693, 22);
            lblUserName_LS.Name = "lblUserName_LS";
            lblUserName_LS.Size = new Size(119, 26);
            lblUserName_LS.TabIndex = 2;
            // 
            // btnThongBao_LS
            // 
            btnThongBao_LS.AutoSize = true;
            btnThongBao_LS.BackColor = Color.FromArgb(255, 241, 230);
            btnThongBao_LS.BackgroundImage = Properties.Resources.bell_regular_24;
            btnThongBao_LS.BackgroundImageLayout = ImageLayout.Zoom;
            btnThongBao_LS.Cursor = Cursors.Hand;
            btnThongBao_LS.FlatAppearance.BorderSize = 0;
            btnThongBao_LS.FlatStyle = FlatStyle.Flat;
            btnThongBao_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThongBao_LS.ForeColor = Color.White;
            btnThongBao_LS.Location = new Point(621, 10);
            btnThongBao_LS.Name = "btnThongBao_LS";
            btnThongBao_LS.Size = new Size(66, 42);
            btnThongBao_LS.TabIndex = 1;
            btnThongBao_LS.UseVisualStyleBackColor = false;
            // 
            // btnThoat_LS
            // 
            btnThoat_LS.AutoSize = true;
            btnThoat_LS.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_LS.BackgroundImage = Properties.Resources.exit;
            btnThoat_LS.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_LS.Cursor = Cursors.Hand;
            btnThoat_LS.FlatAppearance.BorderSize = 0;
            btnThoat_LS.FlatStyle = FlatStyle.Flat;
            btnThoat_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_LS.ForeColor = Color.White;
            btnThoat_LS.Location = new Point(934, 8);
            btnThoat_LS.Name = "btnThoat_LS";
            btnThoat_LS.Size = new Size(66, 46);
            btnThoat_LS.TabIndex = 1;
            btnThoat_LS.UseVisualStyleBackColor = false;
            // 
            // btnUser_LS
            // 
            btnUser_LS.AutoSize = true;
            btnUser_LS.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_LS.BackgroundImage = Properties.Resources.login;
            btnUser_LS.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_LS.Cursor = Cursors.Hand;
            btnUser_LS.FlatAppearance.BorderSize = 0;
            btnUser_LS.FlatStyle = FlatStyle.Flat;
            btnUser_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_LS.ForeColor = Color.White;
            btnUser_LS.Location = new Point(871, 10);
            btnUser_LS.Name = "btnUser_LS";
            btnUser_LS.Size = new Size(66, 42);
            btnUser_LS.TabIndex = 1;
            btnUser_LS.UseVisualStyleBackColor = false;
            // 
            // btnXuatExcel_LS
            // 
            btnXuatExcel_LS.AutoSize = true;
            btnXuatExcel_LS.BackColor = Color.White;
            btnXuatExcel_LS.Cursor = Cursors.Hand;
            btnXuatExcel_LS.FlatAppearance.BorderSize = 0;
            btnXuatExcel_LS.FlatStyle = FlatStyle.Popup;
            btnXuatExcel_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXuatExcel_LS.ForeColor = Color.FromArgb(102, 44, 33);
            btnXuatExcel_LS.Image = Properties.Resources.excel1;
            btnXuatExcel_LS.ImageAlign = ContentAlignment.MiddleLeft;
            btnXuatExcel_LS.Location = new Point(849, 70);
            btnXuatExcel_LS.Name = "btnXuatExcel_LS";
            btnXuatExcel_LS.Size = new Size(144, 42);
            btnXuatExcel_LS.TabIndex = 4;
            btnXuatExcel_LS.Text = "Xuất Excel";
            btnXuatExcel_LS.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnXuatExcel_LS.UseVisualStyleBackColor = false;
            // 
            // txtTimKiem_LS
            // 
            txtTimKiem_LS.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_LS.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_LS.Location = new Point(557, 78);
            txtTimKiem_LS.Multiline = true;
            txtTimKiem_LS.Name = "txtTimKiem_LS";
            txtTimKiem_LS.Size = new Size(255, 27);
            txtTimKiem_LS.TabIndex = 7;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label12.Location = new Point(6, 81);
            label12.Name = "label12";
            label12.Size = new Size(89, 21);
            label12.TabIndex = 8;
            // 
            // dtpStart_LS
            // 
            dtpStart_LS.Format = DateTimePickerFormat.Short;
            dtpStart_LS.Location = new Point(108, 78);
            dtpStart_LS.Name = "dtpStart_LS";
            dtpStart_LS.Size = new Size(101, 27);
            dtpStart_LS.TabIndex = 9;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label13.Location = new Point(215, 81);
            label13.Name = "label13";
            label13.Size = new Size(100, 21);
            label13.TabIndex = 8;
            // 
            // dtpEnd_LS
            // 
            dtpEnd_LS.Format = DateTimePickerFormat.Short;
            dtpEnd_LS.Location = new Point(317, 78);
            dtpEnd_LS.Name = "dtpEnd_LS";
            dtpEnd_LS.Size = new Size(99, 27);
            dtpEnd_LS.TabIndex = 9;
            // 
            // dgvLichSu
            // 
            dgvLichSu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLichSu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLichSu.Dock = DockStyle.Fill;
            dgvLichSu.Location = new Point(0, 125);
            dgvLichSu.Name = "dgvLichSu";
            dgvLichSu.RowHeadersWidth = 51;
            dgvLichSu.Size = new Size(998, 509);
            dgvLichSu.TabIndex = 2;
            // 
            // fNhanVien
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(1262, 673);
            Controls.Add(tabControl1);
            Controls.Add(panel1);
            DoubleBuffered = true;
            Name = "fNhanVien";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Nhân viên";
            FormClosing += fNhanVien_FormClosing;
            Load += fNhanVien_Load;
            panel1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            pnlQuanLyBan.ResumeLayout(false);
            pnl_top_QuanLyban.ResumeLayout(false);
            pnl_top_QuanLyban.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            tabPage1.ResumeLayout(false);
            pnlThucDon.ResumeLayout(false);
            pnlThongTinMon.ResumeLayout(false);
            pnlThongTinMon.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            pnlKhac.ResumeLayout(false);
            pnlBanh.ResumeLayout(false);
            pnlTra.ResumeLayout(false);
            pnlCoffe.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage6.ResumeLayout(false);
            pnlKhachHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).EndInit();
            panel25.ResumeLayout(false);
            panel25.PerformLayout();
            panel26.ResumeLayout(false);
            panel26.PerformLayout();
            panel27.ResumeLayout(false);
            panel27.PerformLayout();
            tabPage7.ResumeLayout(false);
            pnlLichSu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvLichSuCa).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private Button btnThucDon;
        private Button btnQuanLyBan;
        private Button btnKhachHang;
        private Button btnLichSu;
        private Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private TabPage tabPage2;
        private Panel pnlQuanLyBan;
        private Panel pnl_top_QuanLyban;
        private Label label5;
        private Label label4;
        private Panel panel9;
        private Panel panel8;
        private ComboBox cboTrangThai;
        private Panel panel4;
        private Button btnUser_Ban;
        private Button btnThoat_Ban;
        private Label lblUserName_Ban;
        private Panel panel14;
        private Panel panel13;
        private Label label1;
        private Button btnSua_Ban;
        private TabPage tabPage1;
        private Panel pnlThucDon;
        private Panel panel5;
        private TextBox txtTimKiem_ThucDon;
        private Panel panel10;
        private Button btnUser_ThucDon;
        private Button btnThoat_ThucDon;
        private Label lblUsername_TD;
        private Panel panel11;
        private Panel panel12;
        private Label label7;
        private TabControl tabControl1;
        private TabPage tabPage6;
        private Button button5;

        private Panel pnlKhachHang;
        private Panel panel25;
        private Button button9;
        private Panel panel26;
        private Button btnUser_KH;
        private Button btnThoat_KH;
        private Label lblUserName_KH;
        private Panel panel27;
        private Panel panel28;
        private Label label10;
        private TextBox txtTimKiem_KH;
        private DataGridView dgvKhachHang;
        private FlowLayoutPanel flpQuanLyBan;
        private TabPage tabPage7;
        private Panel panel29;
        private Panel panel30;
        private Panel panel31;
        private Label label11;
        private Panel panel32;
        private Label lblUserName_LS;
        private Button btnThongBao_LS;
        private Button btnThoat_LS;
        private Button btnUser_LS;
        private Button btnXuatExcel_LS;
        private TextBox txtTimKiem_LS;
        private Label label12;
        private DateTimePicker dtpStart_LS;
        private Label label13;
        private DateTimePicker dtpEnd_LS;
        private DataGridView dgvLichSu;
        private FlowLayoutPanel fplThucDon;
        private Button btnHuy;
        private Button btnGui;
        private Label lblTongTien;
        private FlowLayoutPanel fplChiTietHoaDon;
        private Panel panel2;
        private Label label8;
        private Label label3;
        private Label label2;
        private Label label9;
        private Button btnCoffe;
        private Panel pnlKhac;
        private FlowLayoutPanel flowLayoutPanel4;
        private Panel pnlBanh;
        private FlowLayoutPanel flowLayoutPanel3;
        private Panel pnlTra;
        private FlowLayoutPanel flowLayoutPanel2;
        private Panel pnlCoffe;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button btnKhac;
        private Button btnBanh;
        private Button btnTra;
        private ComboBox cboLoai;
        private ComboBox cboBan;
        private Panel pnlThongTinMon;
        private Panel pnlLichSu;
        private DataGridView dgvLichSuCa;
        private Panel panel7;
        private TextBox txtTimKiem_LSC;
        private Panel panel15;
        private Button btnUser_LSC;
        private Button btnThoat_LSC;
        private Label lblUserName_LSC;
        private Panel panel16;
        private Panel panel17;
        private Label label14;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem xemThôngTinToolStripMenuItem;
        private ToolStripMenuItem đổiMậtKhẩuToolStripMenuItem;
        private DateTimePicker dtpEndC_LSC;
        private Label label6;
        private DateTimePicker dtpStart_LSC;
        private Label label15;
        private Button button2;
        private Button btnSua_KH;
        private Button btnThem_KH;
    }
}