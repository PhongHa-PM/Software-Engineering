﻿namespace QL_Bida
{
    partial class fHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle16 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle17 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle18 = new DataGridViewCellStyle();
            panel3 = new Panel();
            btnThucDon = new Button();
            btnKho = new Button();
            btnQuanLyBan = new Button();
            btnKhachHang = new Button();
            btnNhanVien = new Button();
            btnLichSu = new Button();
            btnKhuyenMai = new Button();
            panel1 = new Panel();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            tabPage4 = new TabPage();
            pnlKhuyenMai = new Panel();
            dgvKhuyenMai = new DataGridView();
            panel17 = new Panel();
            txtTimKiem_KM = new TextBox();
            btnSua_KM = new Button();
            btnXoa_KM = new Button();
            btnThem_KM = new Button();
            panel18 = new Panel();
            btnUser_KM = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            toolStripMenuItem1 = new ToolStripMenuItem();
            toolStripMenuItem2 = new ToolStripMenuItem();
            btnThoat_KM = new Button();
            lblUserName_KM = new Label();
            panel19 = new Panel();
            panel20 = new Panel();
            label8 = new Label();
            tabPage3 = new TabPage();
            pnlNhanVien = new Panel();
            dgvNhanVien = new DataGridView();
            panel6 = new Panel();
            txtTimKiem_NhanVien = new TextBox();
            btnSua_NhanVien = new Button();
            btnXoa_NhanVien = new Button();
            btnThem_NhanVien = new Button();
            panel7 = new Panel();
            btnUser_NhanVien = new Button();
            btnThoat_NhanVien = new Button();
            lblUserName_NhanVien = new Label();
            panel15 = new Panel();
            panel16 = new Panel();
            label3 = new Label();
            tabPage2 = new TabPage();
            pnlQuanLyBan = new Panel();
            flpQuanLyBan = new FlowLayoutPanel();
            pnl_top_QuanLyban = new Panel();
            label5 = new Label();
            label4 = new Label();
            panel9 = new Panel();
            panel8 = new Panel();
            cboQuanLyBan = new ComboBox();
            panel4 = new Panel();
            btnUser_Ban = new Button();
            btnThoat_Ban = new Button();
            lblUserName_Ban = new Label();
            panel14 = new Panel();
            panel13 = new Panel();
            label1 = new Label();
            btnXoa_Ban = new Button();
            btnSua_Ban = new Button();
            btnThem_Ban = new Button();
            tabPage1 = new TabPage();
            pnlThucDon = new Panel();
            dgvThucDon = new DataGridView();
            panel5 = new Panel();
            cbo_ThucDon = new ComboBox();
            txtTimKiem_ThucDon = new TextBox();
            btnSua_ThucDon = new Button();
            btnXoa_ThucDon = new Button();
            btnThem_ThucDon = new Button();
            panel10 = new Panel();
            btnUser_ThucDon = new Button();
            btnThoat_ThucDon = new Button();
            lblUserName_TD = new Label();
            panel11 = new Panel();
            panel12 = new Panel();
            label7 = new Label();
            tabControl1 = new TabControl();
            tabPage5 = new TabPage();
            pnlKho = new Panel();
            dgvKho = new DataGridView();
            panel21 = new Panel();
            txtTimKiem_Kho = new TextBox();
            btnCapNhat_Kho = new Button();
            panel22 = new Panel();
            btnUser_Kho = new Button();
            btnThoat_Kho = new Button();
            lblUserName_Kho = new Label();
            panel23 = new Panel();
            panel24 = new Panel();
            label9 = new Label();
            tabPage6 = new TabPage();
            pnlKhachHang = new Panel();
            dgvKhachHang = new DataGridView();
            panel25 = new Panel();
            txtTimKiem_KH = new TextBox();
            btnSua_KH = new Button();
            btnXoa_KH = new Button();
            btnThem_KH = new Button();
            panel26 = new Panel();
            btnUser_KH = new Button();
            btnThoat_KH = new Button();
            lblUserName_KH = new Label();
            panel27 = new Panel();
            panel28 = new Panel();
            label10 = new Label();
            tabPage7 = new TabPage();
            pnlLichSu = new Panel();
            dgvLichSu = new DataGridView();
            panel29 = new Panel();
            dtpEnd_LS = new DateTimePicker();
            label13 = new Label();
            dtpStart_LS = new DateTimePicker();
            label12 = new Label();
            txtTimKiem_LS = new TextBox();
            btnXuatExcel_LS = new Button();
            panel30 = new Panel();
            btnUser_LS = new Button();
            btnThoat_LS = new Button();
            lblUserName_LS = new Label();
            panel31 = new Panel();
            panel32 = new Panel();
            label11 = new Label();
            panel1.SuspendLayout();
            tabPage4.SuspendLayout();
            pnlKhuyenMai.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKhuyenMai).BeginInit();
            panel17.SuspendLayout();
            panel18.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            panel19.SuspendLayout();
            tabPage3.SuspendLayout();
            pnlNhanVien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).BeginInit();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel15.SuspendLayout();
            tabPage2.SuspendLayout();
            pnlQuanLyBan.SuspendLayout();
            pnl_top_QuanLyban.SuspendLayout();
            panel4.SuspendLayout();
            panel14.SuspendLayout();
            tabPage1.SuspendLayout();
            pnlThucDon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvThucDon).BeginInit();
            panel5.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage5.SuspendLayout();
            pnlKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKho).BeginInit();
            panel21.SuspendLayout();
            panel22.SuspendLayout();
            panel23.SuspendLayout();
            tabPage6.SuspendLayout();
            pnlKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).BeginInit();
            panel25.SuspendLayout();
            panel26.SuspendLayout();
            panel27.SuspendLayout();
            tabPage7.SuspendLayout();
            pnlLichSu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).BeginInit();
            panel29.SuspendLayout();
            panel30.SuspendLayout();
            panel31.SuspendLayout();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(102, 44, 33);
            panel3.BackgroundImage = Properties.Resources.LOGO_removebg_preview;
            panel3.BackgroundImageLayout = ImageLayout.Zoom;
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(250, 125);
            panel3.TabIndex = 0;
            // 
            // btnThucDon
            // 
            btnThucDon.BackColor = Color.FromArgb(102, 44, 33);
            btnThucDon.Cursor = Cursors.Hand;
            btnThucDon.FlatAppearance.BorderSize = 0;
            btnThucDon.FlatStyle = FlatStyle.Flat;
            btnThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThucDon.ForeColor = Color.White;
            btnThucDon.Image = Properties.Resources.bolw_white;
            btnThucDon.ImageAlign = ContentAlignment.MiddleLeft;
            btnThucDon.Location = new Point(45, 163);
            btnThucDon.Name = "btnThucDon";
            btnThucDon.Size = new Size(166, 51);
            btnThucDon.TabIndex = 1;
            btnThucDon.Text = "Thực Đơn";
            btnThucDon.TextAlign = ContentAlignment.MiddleRight;
            btnThucDon.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnThucDon.UseVisualStyleBackColor = false;
            btnThucDon.Click += btnThucDon_Click;
            // 
            // btnKho
            // 
            btnKho.BackColor = Color.FromArgb(102, 44, 33);
            btnKho.Cursor = Cursors.Hand;
            btnKho.FlatAppearance.BorderSize = 0;
            btnKho.FlatStyle = FlatStyle.Flat;
            btnKho.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnKho.ForeColor = Color.White;
            btnKho.Image = Properties.Resources.store_white;
            btnKho.ImageAlign = ContentAlignment.MiddleLeft;
            btnKho.Location = new Point(45, 391);
            btnKho.Name = "btnKho";
            btnKho.Size = new Size(166, 51);
            btnKho.TabIndex = 1;
            btnKho.Text = "Kho";
            btnKho.TextAlign = ContentAlignment.MiddleRight;
            btnKho.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnKho.UseVisualStyleBackColor = false;
            btnKho.Click += btnKho_Click;
            // 
            // btnQuanLyBan
            // 
            btnQuanLyBan.BackColor = Color.FromArgb(102, 44, 33);
            btnQuanLyBan.Cursor = Cursors.Hand;
            btnQuanLyBan.FlatAppearance.BorderSize = 0;
            btnQuanLyBan.FlatStyle = FlatStyle.Flat;
            btnQuanLyBan.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnQuanLyBan.ForeColor = Color.White;
            btnQuanLyBan.Image = Properties.Resources.plus_white;
            btnQuanLyBan.ImageAlign = ContentAlignment.MiddleLeft;
            btnQuanLyBan.Location = new Point(45, 217);
            btnQuanLyBan.Name = "btnQuanLyBan";
            btnQuanLyBan.Size = new Size(166, 51);
            btnQuanLyBan.TabIndex = 1;
            btnQuanLyBan.Text = "Quản lý bàn";
            btnQuanLyBan.TextAlign = ContentAlignment.MiddleRight;
            btnQuanLyBan.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnQuanLyBan.UseVisualStyleBackColor = false;
            btnQuanLyBan.Click += btnQuanLyBan_Click;
            // 
            // btnKhachHang
            // 
            btnKhachHang.BackColor = Color.FromArgb(102, 44, 33);
            btnKhachHang.Cursor = Cursors.Hand;
            btnKhachHang.FlatAppearance.BorderSize = 0;
            btnKhachHang.FlatStyle = FlatStyle.Flat;
            btnKhachHang.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnKhachHang.ForeColor = Color.White;
            btnKhachHang.Image = Properties.Resources.group_white;
            btnKhachHang.ImageAlign = ContentAlignment.MiddleLeft;
            btnKhachHang.Location = new Point(45, 445);
            btnKhachHang.Name = "btnKhachHang";
            btnKhachHang.Size = new Size(166, 51);
            btnKhachHang.TabIndex = 1;
            btnKhachHang.Text = "Khách hàng";
            btnKhachHang.TextAlign = ContentAlignment.MiddleRight;
            btnKhachHang.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnKhachHang.UseVisualStyleBackColor = false;
            btnKhachHang.Click += btnKhachHang_Click;
            // 
            // btnNhanVien
            // 
            btnNhanVien.BackColor = Color.FromArgb(102, 44, 33);
            btnNhanVien.Cursor = Cursors.Hand;
            btnNhanVien.FlatAppearance.BorderSize = 0;
            btnNhanVien.FlatStyle = FlatStyle.Flat;
            btnNhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnNhanVien.ForeColor = Color.White;
            btnNhanVien.Image = Properties.Resources.user_white;
            btnNhanVien.ImageAlign = ContentAlignment.MiddleLeft;
            btnNhanVien.Location = new Point(45, 274);
            btnNhanVien.Name = "btnNhanVien";
            btnNhanVien.Size = new Size(166, 51);
            btnNhanVien.TabIndex = 1;
            btnNhanVien.Text = "Nhân viên";
            btnNhanVien.TextAlign = ContentAlignment.MiddleRight;
            btnNhanVien.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnNhanVien.UseVisualStyleBackColor = false;
            btnNhanVien.Click += btnNhanVien_Click;
            // 
            // btnLichSu
            // 
            btnLichSu.BackColor = Color.FromArgb(102, 44, 33);
            btnLichSu.Cursor = Cursors.Hand;
            btnLichSu.FlatAppearance.BorderSize = 0;
            btnLichSu.FlatStyle = FlatStyle.Flat;
            btnLichSu.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnLichSu.ForeColor = Color.White;
            btnLichSu.Image = Properties.Resources.history_white;
            btnLichSu.ImageAlign = ContentAlignment.MiddleLeft;
            btnLichSu.Location = new Point(45, 502);
            btnLichSu.Name = "btnLichSu";
            btnLichSu.Size = new Size(166, 51);
            btnLichSu.TabIndex = 1;
            btnLichSu.Text = "Lịch sử";
            btnLichSu.TextAlign = ContentAlignment.MiddleRight;
            btnLichSu.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnLichSu.UseVisualStyleBackColor = false;
            btnLichSu.Click += btnLichSu_Click;
            // 
            // btnKhuyenMai
            // 
            btnKhuyenMai.BackColor = Color.FromArgb(102, 44, 33);
            btnKhuyenMai.Cursor = Cursors.Hand;
            btnKhuyenMai.FlatAppearance.BorderSize = 0;
            btnKhuyenMai.FlatStyle = FlatStyle.Flat;
            btnKhuyenMai.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnKhuyenMai.ForeColor = Color.White;
            btnKhuyenMai.Image = Properties.Resources.gift_white;
            btnKhuyenMai.ImageAlign = ContentAlignment.MiddleLeft;
            btnKhuyenMai.Location = new Point(45, 331);
            btnKhuyenMai.Name = "btnKhuyenMai";
            btnKhuyenMai.Size = new Size(166, 51);
            btnKhuyenMai.TabIndex = 1;
            btnKhuyenMai.Text = "Khuyến mãi";
            btnKhuyenMai.TextAlign = ContentAlignment.MiddleRight;
            btnKhuyenMai.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnKhuyenMai.UseVisualStyleBackColor = false;
            btnKhuyenMai.Click += btnKhuyenMai_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(102, 44, 33);
            panel1.Controls.Add(btnKhuyenMai);
            panel1.Controls.Add(btnLichSu);
            panel1.Controls.Add(btnNhanVien);
            panel1.Controls.Add(btnKhachHang);
            panel1.Controls.Add(btnQuanLyBan);
            panel1.Controls.Add(btnKho);
            panel1.Controls.Add(btnThucDon);
            panel1.Controls.Add(panel3);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 673);
            panel1.TabIndex = 0;
            // 
            // tabPage4
            // 
            tabPage4.Controls.Add(pnlKhuyenMai);
            tabPage4.Location = new Point(4, 29);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(1004, 640);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "tabPage4";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // pnlKhuyenMai
            // 
            pnlKhuyenMai.Controls.Add(dgvKhuyenMai);
            pnlKhuyenMai.Controls.Add(panel17);
            pnlKhuyenMai.Dock = DockStyle.Fill;
            pnlKhuyenMai.Location = new Point(3, 3);
            pnlKhuyenMai.Name = "pnlKhuyenMai";
            pnlKhuyenMai.Size = new Size(998, 634);
            pnlKhuyenMai.TabIndex = 5;
            pnlKhuyenMai.Visible = false;
            // 
            // dgvKhuyenMai
            // 
            dgvKhuyenMai.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvKhuyenMai.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvKhuyenMai.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = Color.Transparent;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvKhuyenMai.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvKhuyenMai.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dgvKhuyenMai.DefaultCellStyle = dataGridViewCellStyle2;
            dgvKhuyenMai.Dock = DockStyle.Fill;
            dgvKhuyenMai.EnableHeadersVisualStyles = false;
            dgvKhuyenMai.GridColor = Color.FromArgb(217, 186, 166);
            dgvKhuyenMai.Location = new Point(0, 125);
            dgvKhuyenMai.Name = "dgvKhuyenMai";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dgvKhuyenMai.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dgvKhuyenMai.RowHeadersVisible = false;
            dgvKhuyenMai.RowHeadersWidth = 51;
            dgvKhuyenMai.Size = new Size(998, 509);
            dgvKhuyenMai.TabIndex = 4;
            // 
            // panel17
            // 
            panel17.BackColor = Color.FromArgb(217, 186, 166);
            panel17.Controls.Add(txtTimKiem_KM);
            panel17.Controls.Add(btnSua_KM);
            panel17.Controls.Add(btnXoa_KM);
            panel17.Controls.Add(btnThem_KM);
            panel17.Controls.Add(panel18);
            panel17.Dock = DockStyle.Top;
            panel17.Location = new Point(0, 0);
            panel17.Name = "panel17";
            panel17.Size = new Size(998, 125);
            panel17.TabIndex = 1;
            // 
            // txtTimKiem_KM
            // 
            txtTimKiem_KM.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_KM.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_KM.Location = new Point(682, 81);
            txtTimKiem_KM.Multiline = true;
            txtTimKiem_KM.Name = "txtTimKiem_KM";
            txtTimKiem_KM.Size = new Size(255, 27);
            txtTimKiem_KM.TabIndex = 7;
            txtTimKiem_KM.Text = "Tìm kiếm ...";
            txtTimKiem_KM.TextChanged += txtTimKiem_KM_TextChanged;
            txtTimKiem_KM.Enter += txtTimKiem_KM_Enter;
            txtTimKiem_KM.Leave += txtTimKiem_KM_Leave;
            // 
            // btnSua_KM
            // 
            btnSua_KM.AutoSize = true;
            btnSua_KM.BackColor = Color.White;
            btnSua_KM.Cursor = Cursors.Hand;
            btnSua_KM.FlatAppearance.BorderSize = 0;
            btnSua_KM.FlatStyle = FlatStyle.Popup;
            btnSua_KM.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_KM.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_KM.Location = new Point(227, 66);
            btnSua_KM.Name = "btnSua_KM";
            btnSua_KM.Size = new Size(80, 42);
            btnSua_KM.TabIndex = 4;
            btnSua_KM.Text = "Sửa";
            btnSua_KM.UseVisualStyleBackColor = false;
            btnSua_KM.Click += btnSua_KM_Click;
            // 
            // btnXoa_KM
            // 
            btnXoa_KM.AutoSize = true;
            btnXoa_KM.BackColor = Color.White;
            btnXoa_KM.Cursor = Cursors.Hand;
            btnXoa_KM.FlatAppearance.BorderSize = 0;
            btnXoa_KM.FlatStyle = FlatStyle.Popup;
            btnXoa_KM.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa_KM.ForeColor = Color.FromArgb(102, 44, 33);
            btnXoa_KM.Location = new Point(126, 66);
            btnXoa_KM.Name = "btnXoa_KM";
            btnXoa_KM.Size = new Size(80, 42);
            btnXoa_KM.TabIndex = 5;
            btnXoa_KM.Text = "Xoá";
            btnXoa_KM.UseVisualStyleBackColor = false;
            btnXoa_KM.Click += btnXoa_KM_Click;
            // 
            // btnThem_KM
            // 
            btnThem_KM.AutoSize = true;
            btnThem_KM.BackColor = Color.White;
            btnThem_KM.Cursor = Cursors.Hand;
            btnThem_KM.FlatAppearance.BorderSize = 0;
            btnThem_KM.FlatStyle = FlatStyle.Popup;
            btnThem_KM.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_KM.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_KM.Location = new Point(28, 66);
            btnThem_KM.Name = "btnThem_KM";
            btnThem_KM.Size = new Size(80, 42);
            btnThem_KM.TabIndex = 6;
            btnThem_KM.Text = "Thêm";
            btnThem_KM.UseVisualStyleBackColor = false;
            btnThem_KM.Click += btnThem_KM_Click;
            // 
            // panel18
            // 
            panel18.BackColor = Color.FromArgb(255, 241, 230);
            panel18.Controls.Add(btnUser_KM);
            panel18.Controls.Add(btnThoat_KM);
            panel18.Controls.Add(lblUserName_KM);
            panel18.Controls.Add(panel19);
            panel18.Dock = DockStyle.Top;
            panel18.Location = new Point(0, 0);
            panel18.Name = "panel18";
            panel18.Size = new Size(998, 62);
            panel18.TabIndex = 0;
            // 
            // btnUser_KM
            // 
            btnUser_KM.AutoSize = true;
            btnUser_KM.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_KM.BackgroundImage = Properties.Resources.login;
            btnUser_KM.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_KM.ContextMenuStrip = contextMenuStrip1;
            btnUser_KM.Cursor = Cursors.Hand;
            btnUser_KM.FlatAppearance.BorderSize = 0;
            btnUser_KM.FlatStyle = FlatStyle.Flat;
            btnUser_KM.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_KM.ForeColor = Color.White;
            btnUser_KM.Location = new Point(871, 10);
            btnUser_KM.Name = "btnUser_KM";
            btnUser_KM.Size = new Size(66, 42);
            btnUser_KM.TabIndex = 1;
            btnUser_KM.UseVisualStyleBackColor = false;
            btnUser_KM.Click += btnUser_KM_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { toolStripMenuItem1, toolStripMenuItem2 });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(173, 52);
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(172, 24);
            toolStripMenuItem1.Text = "Xem thông tin";
            toolStripMenuItem1.Click += toolStripMenuItem1_Click;
            // 
            // toolStripMenuItem2
            // 
            toolStripMenuItem2.Name = "toolStripMenuItem2";
            toolStripMenuItem2.Size = new Size(172, 24);
            toolStripMenuItem2.Text = "Đổi mật khẩu";
            toolStripMenuItem2.Click += toolStripMenuItem2_Click;
            // 
            // btnThoat_KM
            // 
            btnThoat_KM.AutoSize = true;
            btnThoat_KM.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_KM.BackgroundImage = Properties.Resources.exit;
            btnThoat_KM.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_KM.Cursor = Cursors.Hand;
            btnThoat_KM.FlatAppearance.BorderSize = 0;
            btnThoat_KM.FlatStyle = FlatStyle.Flat;
            btnThoat_KM.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_KM.ForeColor = Color.White;
            btnThoat_KM.Location = new Point(934, 8);
            btnThoat_KM.Name = "btnThoat_KM";
            btnThoat_KM.Size = new Size(66, 46);
            btnThoat_KM.TabIndex = 1;
            btnThoat_KM.UseVisualStyleBackColor = false;
            btnThoat_KM.Click += btnThoat_KM_Click;
            // 
            // lblUserName_KM
            // 
            lblUserName_KM.AutoSize = true;
            lblUserName_KM.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_KM.Location = new Point(735, 20);
            lblUserName_KM.Name = "lblUserName_KM";
            lblUserName_KM.Size = new Size(119, 26);
            lblUserName_KM.TabIndex = 2;
            lblUserName_KM.Text = "user name";
            // 
            // panel19
            // 
            panel19.Controls.Add(panel20);
            panel19.Controls.Add(label8);
            panel19.Location = new Point(6, 3);
            panel19.Name = "panel19";
            panel19.Size = new Size(403, 51);
            panel19.TabIndex = 3;
            // 
            // panel20
            // 
            panel20.BackgroundImage = Properties.Resources.gift_black;
            panel20.BackgroundImageLayout = ImageLayout.Zoom;
            panel20.Location = new Point(12, 3);
            panel20.Name = "panel20";
            panel20.Size = new Size(74, 45);
            panel20.TabIndex = 0;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label8.Location = new Point(83, 15);
            label8.Name = "label8";
            label8.Size = new Size(228, 44);
            label8.TabIndex = 2;
            label8.Text = "Khuyến Mãi";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(pnlNhanVien);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1004, 640);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "tabPage3";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // pnlNhanVien
            // 
            pnlNhanVien.Controls.Add(dgvNhanVien);
            pnlNhanVien.Controls.Add(panel6);
            pnlNhanVien.Dock = DockStyle.Fill;
            pnlNhanVien.Location = new Point(3, 3);
            pnlNhanVien.Name = "pnlNhanVien";
            pnlNhanVien.Size = new Size(998, 634);
            pnlNhanVien.TabIndex = 4;
            pnlNhanVien.Visible = false;
            // 
            // dgvNhanVien
            // 
            dgvNhanVien.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvNhanVien.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvNhanVien.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = Color.Transparent;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dgvNhanVien.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dgvNhanVien.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dgvNhanVien.DefaultCellStyle = dataGridViewCellStyle5;
            dgvNhanVien.Dock = DockStyle.Fill;
            dgvNhanVien.EnableHeadersVisualStyles = false;
            dgvNhanVien.GridColor = Color.FromArgb(217, 186, 166);
            dgvNhanVien.Location = new Point(0, 125);
            dgvNhanVien.Name = "dgvNhanVien";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            dgvNhanVien.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            dgvNhanVien.RowHeadersVisible = false;
            dgvNhanVien.RowHeadersWidth = 51;
            dgvNhanVien.Size = new Size(998, 509);
            dgvNhanVien.TabIndex = 4;
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(217, 186, 166);
            panel6.Controls.Add(txtTimKiem_NhanVien);
            panel6.Controls.Add(btnSua_NhanVien);
            panel6.Controls.Add(btnXoa_NhanVien);
            panel6.Controls.Add(btnThem_NhanVien);
            panel6.Controls.Add(panel7);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(998, 125);
            panel6.TabIndex = 1;
            // 
            // txtTimKiem_NhanVien
            // 
            txtTimKiem_NhanVien.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_NhanVien.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_NhanVien.Location = new Point(682, 81);
            txtTimKiem_NhanVien.Multiline = true;
            txtTimKiem_NhanVien.Name = "txtTimKiem_NhanVien";
            txtTimKiem_NhanVien.Size = new Size(255, 27);
            txtTimKiem_NhanVien.TabIndex = 7;
            txtTimKiem_NhanVien.Text = "Tìm kiếm ...";
            txtTimKiem_NhanVien.TextChanged += txtTimKiem_NhanVien_TextChanged;
            txtTimKiem_NhanVien.Enter += txtTimKiem_NhanVien_Enter;
            txtTimKiem_NhanVien.Leave += txtTimKiem_NhanVien_Leave;
            // 
            // btnSua_NhanVien
            // 
            btnSua_NhanVien.AutoSize = true;
            btnSua_NhanVien.BackColor = Color.White;
            btnSua_NhanVien.Cursor = Cursors.Hand;
            btnSua_NhanVien.FlatAppearance.BorderSize = 0;
            btnSua_NhanVien.FlatStyle = FlatStyle.Popup;
            btnSua_NhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_NhanVien.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_NhanVien.Location = new Point(227, 66);
            btnSua_NhanVien.Name = "btnSua_NhanVien";
            btnSua_NhanVien.Size = new Size(80, 42);
            btnSua_NhanVien.TabIndex = 4;
            btnSua_NhanVien.Text = "Sửa";
            btnSua_NhanVien.UseVisualStyleBackColor = false;
            btnSua_NhanVien.Click += btnSua_NhanVien_Click;
            // 
            // btnXoa_NhanVien
            // 
            btnXoa_NhanVien.AutoSize = true;
            btnXoa_NhanVien.BackColor = Color.White;
            btnXoa_NhanVien.Cursor = Cursors.Hand;
            btnXoa_NhanVien.FlatAppearance.BorderSize = 0;
            btnXoa_NhanVien.FlatStyle = FlatStyle.Popup;
            btnXoa_NhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa_NhanVien.ForeColor = Color.FromArgb(102, 44, 33);
            btnXoa_NhanVien.Location = new Point(126, 66);
            btnXoa_NhanVien.Name = "btnXoa_NhanVien";
            btnXoa_NhanVien.Size = new Size(80, 42);
            btnXoa_NhanVien.TabIndex = 5;
            btnXoa_NhanVien.Text = "Xoá";
            btnXoa_NhanVien.UseVisualStyleBackColor = false;
            btnXoa_NhanVien.Click += btnXoa_NhanVien_Click;
            // 
            // btnThem_NhanVien
            // 
            btnThem_NhanVien.AutoSize = true;
            btnThem_NhanVien.BackColor = Color.White;
            btnThem_NhanVien.Cursor = Cursors.Hand;
            btnThem_NhanVien.FlatAppearance.BorderSize = 0;
            btnThem_NhanVien.FlatStyle = FlatStyle.Popup;
            btnThem_NhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_NhanVien.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_NhanVien.Location = new Point(28, 66);
            btnThem_NhanVien.Name = "btnThem_NhanVien";
            btnThem_NhanVien.Size = new Size(80, 42);
            btnThem_NhanVien.TabIndex = 6;
            btnThem_NhanVien.Text = "Thêm";
            btnThem_NhanVien.UseVisualStyleBackColor = false;
            btnThem_NhanVien.Click += btnThem_NhanVien_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.FromArgb(255, 241, 230);
            panel7.Controls.Add(btnUser_NhanVien);
            panel7.Controls.Add(btnThoat_NhanVien);
            panel7.Controls.Add(lblUserName_NhanVien);
            panel7.Controls.Add(panel15);
            panel7.Dock = DockStyle.Top;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(998, 62);
            panel7.TabIndex = 0;
            // 
            // btnUser_NhanVien
            // 
            btnUser_NhanVien.AutoSize = true;
            btnUser_NhanVien.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_NhanVien.BackgroundImage = Properties.Resources.login;
            btnUser_NhanVien.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_NhanVien.ContextMenuStrip = contextMenuStrip1;
            btnUser_NhanVien.Cursor = Cursors.Hand;
            btnUser_NhanVien.FlatAppearance.BorderSize = 0;
            btnUser_NhanVien.FlatStyle = FlatStyle.Flat;
            btnUser_NhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_NhanVien.ForeColor = Color.White;
            btnUser_NhanVien.Location = new Point(871, 10);
            btnUser_NhanVien.Name = "btnUser_NhanVien";
            btnUser_NhanVien.Size = new Size(66, 42);
            btnUser_NhanVien.TabIndex = 1;
            btnUser_NhanVien.UseVisualStyleBackColor = false;
            btnUser_NhanVien.Click += btnUser_NhanVien_Click;
            // 
            // btnThoat_NhanVien
            // 
            btnThoat_NhanVien.AutoSize = true;
            btnThoat_NhanVien.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_NhanVien.BackgroundImage = Properties.Resources.exit;
            btnThoat_NhanVien.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_NhanVien.Cursor = Cursors.Hand;
            btnThoat_NhanVien.FlatAppearance.BorderSize = 0;
            btnThoat_NhanVien.FlatStyle = FlatStyle.Flat;
            btnThoat_NhanVien.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_NhanVien.ForeColor = Color.White;
            btnThoat_NhanVien.Location = new Point(934, 8);
            btnThoat_NhanVien.Name = "btnThoat_NhanVien";
            btnThoat_NhanVien.Size = new Size(66, 46);
            btnThoat_NhanVien.TabIndex = 1;
            btnThoat_NhanVien.UseVisualStyleBackColor = false;
            btnThoat_NhanVien.Click += btnThoat_NhanVien_Click;
            // 
            // lblUserName_NhanVien
            // 
            lblUserName_NhanVien.AutoSize = true;
            lblUserName_NhanVien.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_NhanVien.Location = new Point(735, 20);
            lblUserName_NhanVien.Name = "lblUserName_NhanVien";
            lblUserName_NhanVien.Size = new Size(119, 26);
            lblUserName_NhanVien.TabIndex = 2;
            lblUserName_NhanVien.Text = "user name";
            // 
            // panel15
            // 
            panel15.Controls.Add(panel16);
            panel15.Controls.Add(label3);
            panel15.Location = new Point(6, 3);
            panel15.Name = "panel15";
            panel15.Size = new Size(403, 51);
            panel15.TabIndex = 3;
            // 
            // panel16
            // 
            panel16.BackgroundImage = Properties.Resources.user_black;
            panel16.BackgroundImageLayout = ImageLayout.Zoom;
            panel16.Location = new Point(12, 3);
            panel16.Name = "panel16";
            panel16.Size = new Size(74, 45);
            panel16.TabIndex = 0;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label3.Location = new Point(83, 15);
            label3.Name = "label3";
            label3.Size = new Size(201, 44);
            label3.TabIndex = 2;
            label3.Text = "Nhân Viên";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(pnlQuanLyBan);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1004, 640);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "tabPage2";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlQuanLyBan
            // 
            pnlQuanLyBan.Controls.Add(flpQuanLyBan);
            pnlQuanLyBan.Controls.Add(pnl_top_QuanLyban);
            pnlQuanLyBan.Dock = DockStyle.Fill;
            pnlQuanLyBan.Location = new Point(3, 3);
            pnlQuanLyBan.Name = "pnlQuanLyBan";
            pnlQuanLyBan.Size = new Size(998, 634);
            pnlQuanLyBan.TabIndex = 2;
            pnlQuanLyBan.Visible = false;
            // 
            // flpQuanLyBan
            // 
            flpQuanLyBan.AutoScroll = true;
            flpQuanLyBan.BackColor = Color.White;
            flpQuanLyBan.Dock = DockStyle.Fill;
            flpQuanLyBan.Location = new Point(0, 125);
            flpQuanLyBan.Name = "flpQuanLyBan";
            flpQuanLyBan.Size = new Size(998, 509);
            flpQuanLyBan.TabIndex = 2;
            // 
            // pnl_top_QuanLyban
            // 
            pnl_top_QuanLyban.BackColor = Color.FromArgb(217, 186, 166);
            pnl_top_QuanLyban.Controls.Add(label5);
            pnl_top_QuanLyban.Controls.Add(label4);
            pnl_top_QuanLyban.Controls.Add(panel9);
            pnl_top_QuanLyban.Controls.Add(panel8);
            pnl_top_QuanLyban.Controls.Add(cboQuanLyBan);
            pnl_top_QuanLyban.Controls.Add(panel4);
            pnl_top_QuanLyban.Controls.Add(btnXoa_Ban);
            pnl_top_QuanLyban.Controls.Add(btnSua_Ban);
            pnl_top_QuanLyban.Controls.Add(btnThem_Ban);
            pnl_top_QuanLyban.Dock = DockStyle.Top;
            pnl_top_QuanLyban.Location = new Point(0, 0);
            pnl_top_QuanLyban.Name = "pnl_top_QuanLyban";
            pnl_top_QuanLyban.Size = new Size(998, 125);
            pnl_top_QuanLyban.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.Location = new Point(750, 81);
            label5.Name = "label5";
            label5.Size = new Size(32, 25);
            label5.TabIndex = 5;
            label5.Text = "Lỗ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(634, 81);
            label4.Name = "label4";
            label4.Size = new Size(66, 25);
            label4.TabIndex = 5;
            label4.Text = "Phăng";
            // 
            // panel9
            // 
            panel9.BackColor = Color.FromArgb(254, 142, 142);
            panel9.Location = new Point(704, 81);
            panel9.Name = "panel9";
            panel9.Size = new Size(40, 27);
            panel9.TabIndex = 4;
            // 
            // panel8
            // 
            panel8.BackColor = Color.FromArgb(0, 203, 206);
            panel8.Location = new Point(588, 81);
            panel8.Name = "panel8";
            panel8.Size = new Size(40, 27);
            panel8.TabIndex = 4;
            // 
            // cboQuanLyBan
            // 
            cboQuanLyBan.FlatStyle = FlatStyle.Popup;
            cboQuanLyBan.FormattingEnabled = true;
            cboQuanLyBan.Location = new Point(838, 82);
            cboQuanLyBan.Name = "cboQuanLyBan";
            cboQuanLyBan.Size = new Size(80, 28);
            cboQuanLyBan.TabIndex = 3;
            cboQuanLyBan.SelectedIndexChanged += cboQuanLyBan_SelectedIndexChanged;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(255, 241, 230);
            panel4.Controls.Add(btnUser_Ban);
            panel4.Controls.Add(btnThoat_Ban);
            panel4.Controls.Add(lblUserName_Ban);
            panel4.Controls.Add(panel14);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(998, 62);
            panel4.TabIndex = 0;
            // 
            // btnUser_Ban
            // 
            btnUser_Ban.AutoSize = true;
            btnUser_Ban.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_Ban.BackgroundImage = Properties.Resources.login;
            btnUser_Ban.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_Ban.ContextMenuStrip = contextMenuStrip1;
            btnUser_Ban.Cursor = Cursors.Hand;
            btnUser_Ban.FlatAppearance.BorderSize = 0;
            btnUser_Ban.FlatStyle = FlatStyle.Flat;
            btnUser_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_Ban.ForeColor = Color.White;
            btnUser_Ban.Location = new Point(871, 10);
            btnUser_Ban.Name = "btnUser_Ban";
            btnUser_Ban.Size = new Size(66, 42);
            btnUser_Ban.TabIndex = 1;
            btnUser_Ban.UseVisualStyleBackColor = false;
            btnUser_Ban.Click += btnUser_Ban_Click;
            // 
            // btnThoat_Ban
            // 
            btnThoat_Ban.AutoSize = true;
            btnThoat_Ban.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_Ban.BackgroundImage = Properties.Resources.exit;
            btnThoat_Ban.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_Ban.Cursor = Cursors.Hand;
            btnThoat_Ban.FlatAppearance.BorderSize = 0;
            btnThoat_Ban.FlatStyle = FlatStyle.Flat;
            btnThoat_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_Ban.ForeColor = Color.White;
            btnThoat_Ban.Location = new Point(934, 8);
            btnThoat_Ban.Name = "btnThoat_Ban";
            btnThoat_Ban.Size = new Size(66, 46);
            btnThoat_Ban.TabIndex = 1;
            btnThoat_Ban.UseVisualStyleBackColor = false;
            btnThoat_Ban.Click += btnThoat_Ban_Click;
            // 
            // lblUserName_Ban
            // 
            lblUserName_Ban.AutoSize = true;
            lblUserName_Ban.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_Ban.Location = new Point(735, 20);
            lblUserName_Ban.Name = "lblUserName_Ban";
            lblUserName_Ban.Size = new Size(119, 26);
            lblUserName_Ban.TabIndex = 2;
            lblUserName_Ban.Text = "user name";
            // 
            // panel14
            // 
            panel14.Controls.Add(panel13);
            panel14.Controls.Add(label1);
            panel14.Location = new Point(6, 3);
            panel14.Name = "panel14";
            panel14.Size = new Size(403, 51);
            panel14.TabIndex = 3;
            // 
            // panel13
            // 
            panel13.BackgroundImage = Properties.Resources.plus_black;
            panel13.BackgroundImageLayout = ImageLayout.Zoom;
            panel13.Location = new Point(12, 3);
            panel13.Name = "panel13";
            panel13.Size = new Size(74, 45);
            panel13.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label1.Location = new Point(83, 15);
            label1.Name = "label1";
            label1.Size = new Size(249, 44);
            label1.TabIndex = 2;
            label1.Text = "Quản Lý Bàn";
            // 
            // btnXoa_Ban
            // 
            btnXoa_Ban.AutoSize = true;
            btnXoa_Ban.BackColor = Color.White;
            btnXoa_Ban.Cursor = Cursors.Hand;
            btnXoa_Ban.FlatAppearance.BorderSize = 0;
            btnXoa_Ban.FlatStyle = FlatStyle.Popup;
            btnXoa_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa_Ban.ForeColor = Color.FromArgb(102, 44, 33);
            btnXoa_Ban.Location = new Point(308, 68);
            btnXoa_Ban.Name = "btnXoa_Ban";
            btnXoa_Ban.Size = new Size(101, 42);
            btnXoa_Ban.TabIndex = 1;
            btnXoa_Ban.Text = "Xoá Bàn";
            btnXoa_Ban.UseVisualStyleBackColor = false;
            btnXoa_Ban.Click += btnXoa_Ban_Click;
            // 
            // btnSua_Ban
            // 
            btnSua_Ban.AutoSize = true;
            btnSua_Ban.BackColor = Color.White;
            btnSua_Ban.Cursor = Cursors.Hand;
            btnSua_Ban.FlatAppearance.BorderSize = 0;
            btnSua_Ban.FlatStyle = FlatStyle.Popup;
            btnSua_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_Ban.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_Ban.Location = new Point(187, 68);
            btnSua_Ban.Name = "btnSua_Ban";
            btnSua_Ban.Size = new Size(101, 42);
            btnSua_Ban.TabIndex = 1;
            btnSua_Ban.Text = "Sửa Bàn";
            btnSua_Ban.UseVisualStyleBackColor = false;
            btnSua_Ban.Click += btnSua_Ban_Click;
            // 
            // btnThem_Ban
            // 
            btnThem_Ban.AutoSize = true;
            btnThem_Ban.BackColor = Color.White;
            btnThem_Ban.Cursor = Cursors.Hand;
            btnThem_Ban.FlatAppearance.BorderSize = 0;
            btnThem_Ban.FlatStyle = FlatStyle.Popup;
            btnThem_Ban.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_Ban.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_Ban.Location = new Point(47, 68);
            btnThem_Ban.Name = "btnThem_Ban";
            btnThem_Ban.Size = new Size(116, 42);
            btnThem_Ban.TabIndex = 1;
            btnThem_Ban.Text = "Thêm Bàn";
            btnThem_Ban.UseVisualStyleBackColor = false;
            btnThem_Ban.Click += btnThem_Ban_Click;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(pnlThucDon);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1004, 640);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "tabPage1";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnlThucDon
            // 
            pnlThucDon.Controls.Add(dgvThucDon);
            pnlThucDon.Controls.Add(panel5);
            pnlThucDon.Dock = DockStyle.Fill;
            pnlThucDon.Location = new Point(3, 3);
            pnlThucDon.Name = "pnlThucDon";
            pnlThucDon.Size = new Size(998, 634);
            pnlThucDon.TabIndex = 3;
            pnlThucDon.Visible = false;
            // 
            // dgvThucDon
            // 
            dgvThucDon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvThucDon.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvThucDon.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle7.ForeColor = Color.Transparent;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            dgvThucDon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dgvThucDon.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dgvThucDon.DefaultCellStyle = dataGridViewCellStyle8;
            dgvThucDon.Dock = DockStyle.Fill;
            dgvThucDon.EnableHeadersVisualStyles = false;
            dgvThucDon.GridColor = Color.FromArgb(217, 186, 166);
            dgvThucDon.Location = new Point(0, 125);
            dgvThucDon.Name = "dgvThucDon";
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle9.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle9.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle9.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.True;
            dgvThucDon.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dgvThucDon.RowHeadersVisible = false;
            dgvThucDon.RowHeadersWidth = 51;
            dgvThucDon.Size = new Size(998, 509);
            dgvThucDon.TabIndex = 3;
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(217, 186, 166);
            panel5.Controls.Add(cbo_ThucDon);
            panel5.Controls.Add(txtTimKiem_ThucDon);
            panel5.Controls.Add(btnSua_ThucDon);
            panel5.Controls.Add(btnXoa_ThucDon);
            panel5.Controls.Add(btnThem_ThucDon);
            panel5.Controls.Add(panel10);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(998, 125);
            panel5.TabIndex = 1;
            // 
            // cbo_ThucDon
            // 
            cbo_ThucDon.FlatStyle = FlatStyle.Popup;
            cbo_ThucDon.FormattingEnabled = true;
            cbo_ThucDon.Location = new Point(857, 80);
            cbo_ThucDon.Name = "cbo_ThucDon";
            cbo_ThucDon.Size = new Size(109, 28);
            cbo_ThucDon.TabIndex = 8;
            cbo_ThucDon.Text = "Tất cả";
            cbo_ThucDon.SelectedIndexChanged += cbo_ThucDon_SelectedIndexChanged;
            // 
            // txtTimKiem_ThucDon
            // 
            txtTimKiem_ThucDon.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_ThucDon.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_ThucDon.Location = new Point(557, 79);
            txtTimKiem_ThucDon.Multiline = true;
            txtTimKiem_ThucDon.Name = "txtTimKiem_ThucDon";
            txtTimKiem_ThucDon.Size = new Size(255, 27);
            txtTimKiem_ThucDon.TabIndex = 7;
            txtTimKiem_ThucDon.Text = "Tìm kiếm ...";
            txtTimKiem_ThucDon.TextChanged += txtTimKiem_ThucDon_TextChanged;
            txtTimKiem_ThucDon.Enter += txtTimKiem_ThucDon_Enter;
            txtTimKiem_ThucDon.Leave += txtTimKiem_ThucDon_Leave;
            // 
            // btnSua_ThucDon
            // 
            btnSua_ThucDon.AutoSize = true;
            btnSua_ThucDon.BackColor = Color.White;
            btnSua_ThucDon.Cursor = Cursors.Hand;
            btnSua_ThucDon.FlatAppearance.BorderSize = 0;
            btnSua_ThucDon.FlatStyle = FlatStyle.Popup;
            btnSua_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_ThucDon.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_ThucDon.Location = new Point(227, 66);
            btnSua_ThucDon.Name = "btnSua_ThucDon";
            btnSua_ThucDon.Size = new Size(80, 42);
            btnSua_ThucDon.TabIndex = 4;
            btnSua_ThucDon.Text = "Sửa";
            btnSua_ThucDon.UseVisualStyleBackColor = false;
            btnSua_ThucDon.Click += btnSua_ThucDon_Click;
            // 
            // btnXoa_ThucDon
            // 
            btnXoa_ThucDon.AutoSize = true;
            btnXoa_ThucDon.BackColor = Color.White;
            btnXoa_ThucDon.Cursor = Cursors.Hand;
            btnXoa_ThucDon.FlatAppearance.BorderSize = 0;
            btnXoa_ThucDon.FlatStyle = FlatStyle.Popup;
            btnXoa_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa_ThucDon.ForeColor = Color.FromArgb(102, 44, 33);
            btnXoa_ThucDon.Location = new Point(126, 66);
            btnXoa_ThucDon.Name = "btnXoa_ThucDon";
            btnXoa_ThucDon.Size = new Size(80, 42);
            btnXoa_ThucDon.TabIndex = 5;
            btnXoa_ThucDon.Text = "Xoá";
            btnXoa_ThucDon.UseVisualStyleBackColor = false;
            btnXoa_ThucDon.Click += btnXoa_ThucDon_Click;
            // 
            // btnThem_ThucDon
            // 
            btnThem_ThucDon.AutoSize = true;
            btnThem_ThucDon.BackColor = Color.White;
            btnThem_ThucDon.Cursor = Cursors.Hand;
            btnThem_ThucDon.FlatAppearance.BorderSize = 0;
            btnThem_ThucDon.FlatStyle = FlatStyle.Popup;
            btnThem_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_ThucDon.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_ThucDon.Location = new Point(28, 66);
            btnThem_ThucDon.Name = "btnThem_ThucDon";
            btnThem_ThucDon.Size = new Size(80, 42);
            btnThem_ThucDon.TabIndex = 6;
            btnThem_ThucDon.Text = "Thêm";
            btnThem_ThucDon.UseVisualStyleBackColor = false;
            btnThem_ThucDon.Click += btnThem_ThucDon_Click;
            // 
            // panel10
            // 
            panel10.BackColor = Color.FromArgb(255, 241, 230);
            panel10.Controls.Add(btnUser_ThucDon);
            panel10.Controls.Add(btnThoat_ThucDon);
            panel10.Controls.Add(lblUserName_TD);
            panel10.Controls.Add(panel11);
            panel10.Dock = DockStyle.Top;
            panel10.Location = new Point(0, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(998, 62);
            panel10.TabIndex = 0;
            // 
            // btnUser_ThucDon
            // 
            btnUser_ThucDon.AutoSize = true;
            btnUser_ThucDon.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_ThucDon.BackgroundImage = Properties.Resources.login;
            btnUser_ThucDon.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_ThucDon.ContextMenuStrip = contextMenuStrip1;
            btnUser_ThucDon.Cursor = Cursors.Hand;
            btnUser_ThucDon.FlatAppearance.BorderSize = 0;
            btnUser_ThucDon.FlatStyle = FlatStyle.Flat;
            btnUser_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_ThucDon.ForeColor = Color.White;
            btnUser_ThucDon.Location = new Point(871, 10);
            btnUser_ThucDon.Name = "btnUser_ThucDon";
            btnUser_ThucDon.Size = new Size(66, 42);
            btnUser_ThucDon.TabIndex = 1;
            btnUser_ThucDon.UseVisualStyleBackColor = false;
            btnUser_ThucDon.Click += btnUser_ThucDon_Click;
            // 
            // btnThoat_ThucDon
            // 
            btnThoat_ThucDon.AutoSize = true;
            btnThoat_ThucDon.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_ThucDon.BackgroundImage = Properties.Resources.exit;
            btnThoat_ThucDon.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_ThucDon.Cursor = Cursors.Hand;
            btnThoat_ThucDon.FlatAppearance.BorderSize = 0;
            btnThoat_ThucDon.FlatStyle = FlatStyle.Flat;
            btnThoat_ThucDon.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_ThucDon.ForeColor = Color.White;
            btnThoat_ThucDon.Location = new Point(934, 8);
            btnThoat_ThucDon.Name = "btnThoat_ThucDon";
            btnThoat_ThucDon.Size = new Size(66, 46);
            btnThoat_ThucDon.TabIndex = 1;
            btnThoat_ThucDon.UseVisualStyleBackColor = false;
            btnThoat_ThucDon.Click += btnThoat_ThucDon_Click;
            // 
            // lblUserName_TD
            // 
            lblUserName_TD.AutoSize = true;
            lblUserName_TD.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_TD.Location = new Point(735, 20);
            lblUserName_TD.Name = "lblUserName_TD";
            lblUserName_TD.Size = new Size(119, 26);
            lblUserName_TD.TabIndex = 2;
            lblUserName_TD.Text = "user name";
            // 
            // panel11
            // 
            panel11.Controls.Add(panel12);
            panel11.Controls.Add(label7);
            panel11.Location = new Point(6, 3);
            panel11.Name = "panel11";
            panel11.Size = new Size(403, 51);
            panel11.TabIndex = 3;
            // 
            // panel12
            // 
            panel12.BackgroundImage = Properties.Resources.bolw_black;
            panel12.BackgroundImageLayout = ImageLayout.Zoom;
            panel12.Location = new Point(12, 3);
            panel12.Name = "panel12";
            panel12.Size = new Size(74, 45);
            panel12.TabIndex = 0;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(83, 15);
            label7.Name = "label7";
            label7.Size = new Size(199, 44);
            label7.TabIndex = 2;
            label7.Text = "Thực Đơn";
            // 
            // tabControl1
            // 
            tabControl1.ContextMenuStrip = contextMenuStrip1;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage6);
            tabControl1.Controls.Add(tabPage7);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl1.Location = new Point(250, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1012, 673);
            tabControl1.TabIndex = 3;
            tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(pnlKho);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1004, 640);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "tabPage5";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // pnlKho
            // 
            pnlKho.Controls.Add(dgvKho);
            pnlKho.Controls.Add(panel21);
            pnlKho.Dock = DockStyle.Fill;
            pnlKho.Location = new Point(3, 3);
            pnlKho.Name = "pnlKho";
            pnlKho.Size = new Size(998, 634);
            pnlKho.TabIndex = 4;
            pnlKho.Visible = false;
            // 
            // dgvKho
            // 
            dgvKho.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvKho.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvKho.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle10.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle10.ForeColor = Color.Transparent;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            dgvKho.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            dgvKho.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle11.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle11.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            dgvKho.DefaultCellStyle = dataGridViewCellStyle11;
            dgvKho.Dock = DockStyle.Fill;
            dgvKho.EnableHeadersVisualStyles = false;
            dgvKho.GridColor = Color.FromArgb(217, 186, 166);
            dgvKho.Location = new Point(0, 125);
            dgvKho.Name = "dgvKho";
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle12.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle12.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle12.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            dgvKho.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            dgvKho.RowHeadersVisible = false;
            dgvKho.RowHeadersWidth = 51;
            dgvKho.Size = new Size(998, 509);
            dgvKho.TabIndex = 5;
            dgvKho.CellClick += dgvKho_CellClick;
            // 
            // panel21
            // 
            panel21.BackColor = Color.FromArgb(217, 186, 166);
            panel21.Controls.Add(txtTimKiem_Kho);
            panel21.Controls.Add(btnCapNhat_Kho);
            panel21.Controls.Add(panel22);
            panel21.Dock = DockStyle.Top;
            panel21.Location = new Point(0, 0);
            panel21.Name = "panel21";
            panel21.Size = new Size(998, 125);
            panel21.TabIndex = 1;
            // 
            // txtTimKiem_Kho
            // 
            txtTimKiem_Kho.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_Kho.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_Kho.Location = new Point(557, 78);
            txtTimKiem_Kho.Multiline = true;
            txtTimKiem_Kho.Name = "txtTimKiem_Kho";
            txtTimKiem_Kho.Size = new Size(255, 27);
            txtTimKiem_Kho.TabIndex = 7;
            txtTimKiem_Kho.Text = "Tìm kiếm ...";
            txtTimKiem_Kho.TextChanged += txtTimKiem_Kho_TextChanged;
            txtTimKiem_Kho.Enter += txtTimKiem_Kho_Enter;
            txtTimKiem_Kho.Leave += txtTimKiem_Kho_Leave;
            // 
            // btnCapNhat_Kho
            // 
            btnCapNhat_Kho.AutoSize = true;
            btnCapNhat_Kho.BackColor = Color.White;
            btnCapNhat_Kho.Cursor = Cursors.Hand;
            btnCapNhat_Kho.FlatAppearance.BorderSize = 0;
            btnCapNhat_Kho.FlatStyle = FlatStyle.Popup;
            btnCapNhat_Kho.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnCapNhat_Kho.ForeColor = Color.FromArgb(102, 44, 33);
            btnCapNhat_Kho.Location = new Point(28, 66);
            btnCapNhat_Kho.Name = "btnCapNhat_Kho";
            btnCapNhat_Kho.Size = new Size(197, 42);
            btnCapNhat_Kho.TabIndex = 6;
            btnCapNhat_Kho.Text = "Cập nhật số lượng";
            btnCapNhat_Kho.UseVisualStyleBackColor = false;
            btnCapNhat_Kho.Click += btnCapNhat_Kho_Click;
            // 
            // panel22
            // 
            panel22.BackColor = Color.FromArgb(255, 241, 230);
            panel22.Controls.Add(btnUser_Kho);
            panel22.Controls.Add(btnThoat_Kho);
            panel22.Controls.Add(lblUserName_Kho);
            panel22.Controls.Add(panel23);
            panel22.Dock = DockStyle.Top;
            panel22.Location = new Point(0, 0);
            panel22.Name = "panel22";
            panel22.Size = new Size(998, 62);
            panel22.TabIndex = 0;
            // 
            // btnUser_Kho
            // 
            btnUser_Kho.AutoSize = true;
            btnUser_Kho.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_Kho.BackgroundImage = Properties.Resources.login;
            btnUser_Kho.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_Kho.ContextMenuStrip = contextMenuStrip1;
            btnUser_Kho.Cursor = Cursors.Hand;
            btnUser_Kho.FlatAppearance.BorderSize = 0;
            btnUser_Kho.FlatStyle = FlatStyle.Flat;
            btnUser_Kho.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_Kho.ForeColor = Color.White;
            btnUser_Kho.Location = new Point(871, 10);
            btnUser_Kho.Name = "btnUser_Kho";
            btnUser_Kho.Size = new Size(66, 42);
            btnUser_Kho.TabIndex = 1;
            btnUser_Kho.UseVisualStyleBackColor = false;
            btnUser_Kho.Click += btnUser_Kho_Click;
            // 
            // btnThoat_Kho
            // 
            btnThoat_Kho.AutoSize = true;
            btnThoat_Kho.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_Kho.BackgroundImage = Properties.Resources.exit;
            btnThoat_Kho.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_Kho.Cursor = Cursors.Hand;
            btnThoat_Kho.FlatAppearance.BorderSize = 0;
            btnThoat_Kho.FlatStyle = FlatStyle.Flat;
            btnThoat_Kho.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_Kho.ForeColor = Color.White;
            btnThoat_Kho.Location = new Point(934, 8);
            btnThoat_Kho.Name = "btnThoat_Kho";
            btnThoat_Kho.Size = new Size(66, 46);
            btnThoat_Kho.TabIndex = 1;
            btnThoat_Kho.UseVisualStyleBackColor = false;
            btnThoat_Kho.Click += btnThoat_Kho_Click;
            // 
            // lblUserName_Kho
            // 
            lblUserName_Kho.AutoSize = true;
            lblUserName_Kho.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_Kho.Location = new Point(735, 20);
            lblUserName_Kho.Name = "lblUserName_Kho";
            lblUserName_Kho.Size = new Size(119, 26);
            lblUserName_Kho.TabIndex = 2;
            lblUserName_Kho.Text = "user name";
            // 
            // panel23
            // 
            panel23.Controls.Add(panel24);
            panel23.Controls.Add(label9);
            panel23.Location = new Point(6, 3);
            panel23.Name = "panel23";
            panel23.Size = new Size(403, 51);
            panel23.TabIndex = 3;
            // 
            // panel24
            // 
            panel24.BackgroundImage = Properties.Resources.store_black;
            panel24.BackgroundImageLayout = ImageLayout.Zoom;
            panel24.Location = new Point(12, 3);
            panel24.Name = "panel24";
            panel24.Size = new Size(74, 45);
            panel24.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label9.Location = new Point(83, 15);
            label9.Name = "label9";
            label9.Size = new Size(92, 44);
            label9.TabIndex = 2;
            label9.Text = "Kho";
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(pnlKhachHang);
            tabPage6.Location = new Point(4, 29);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(1004, 640);
            tabPage6.TabIndex = 5;
            tabPage6.Text = "tabPage6";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // pnlKhachHang
            // 
            pnlKhachHang.Controls.Add(dgvKhachHang);
            pnlKhachHang.Controls.Add(panel25);
            pnlKhachHang.Dock = DockStyle.Fill;
            pnlKhachHang.Location = new Point(3, 3);
            pnlKhachHang.Name = "pnlKhachHang";
            pnlKhachHang.Size = new Size(998, 634);
            pnlKhachHang.TabIndex = 5;
            pnlKhachHang.Visible = false;
            // 
            // dgvKhachHang
            // 
            dgvKhachHang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvKhachHang.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvKhachHang.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle13.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle13.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle13.ForeColor = Color.Transparent;
            dataGridViewCellStyle13.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle13.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = DataGridViewTriState.True;
            dgvKhachHang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            dgvKhachHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle14.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle14.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.False;
            dgvKhachHang.DefaultCellStyle = dataGridViewCellStyle14;
            dgvKhachHang.Dock = DockStyle.Fill;
            dgvKhachHang.EnableHeadersVisualStyles = false;
            dgvKhachHang.GridColor = Color.FromArgb(217, 186, 166);
            dgvKhachHang.Location = new Point(0, 125);
            dgvKhachHang.Name = "dgvKhachHang";
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle15.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle15.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle15.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.True;
            dgvKhachHang.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            dgvKhachHang.RowHeadersVisible = false;
            dgvKhachHang.RowHeadersWidth = 51;
            dgvKhachHang.Size = new Size(998, 509);
            dgvKhachHang.TabIndex = 6;
            // 
            // panel25
            // 
            panel25.BackColor = Color.FromArgb(217, 186, 166);
            panel25.Controls.Add(txtTimKiem_KH);
            panel25.Controls.Add(btnSua_KH);
            panel25.Controls.Add(btnXoa_KH);
            panel25.Controls.Add(btnThem_KH);
            panel25.Controls.Add(panel26);
            panel25.Dock = DockStyle.Top;
            panel25.Location = new Point(0, 0);
            panel25.Name = "panel25";
            panel25.Size = new Size(998, 125);
            panel25.TabIndex = 1;
            // 
            // txtTimKiem_KH
            // 
            txtTimKiem_KH.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_KH.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_KH.Location = new Point(682, 81);
            txtTimKiem_KH.Multiline = true;
            txtTimKiem_KH.Name = "txtTimKiem_KH";
            txtTimKiem_KH.Size = new Size(255, 27);
            txtTimKiem_KH.TabIndex = 8;
            txtTimKiem_KH.Text = "Tìm kiếm ...";
            txtTimKiem_KH.TextChanged += txtTimKiem_KH_TextChanged;
            txtTimKiem_KH.Enter += txtTimKiem_KH_Enter;
            txtTimKiem_KH.Leave += txtTimKiem_KH_Leave;
            // 
            // btnSua_KH
            // 
            btnSua_KH.AutoSize = true;
            btnSua_KH.BackColor = Color.White;
            btnSua_KH.Cursor = Cursors.Hand;
            btnSua_KH.FlatAppearance.BorderSize = 0;
            btnSua_KH.FlatStyle = FlatStyle.Popup;
            btnSua_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnSua_KH.ForeColor = Color.FromArgb(102, 44, 33);
            btnSua_KH.Location = new Point(231, 66);
            btnSua_KH.Name = "btnSua_KH";
            btnSua_KH.Size = new Size(80, 42);
            btnSua_KH.TabIndex = 5;
            btnSua_KH.Text = "Sửa";
            btnSua_KH.UseVisualStyleBackColor = false;
            btnSua_KH.Click += btnSua_KH_Click;
            // 
            // btnXoa_KH
            // 
            btnXoa_KH.AutoSize = true;
            btnXoa_KH.BackColor = Color.White;
            btnXoa_KH.Cursor = Cursors.Hand;
            btnXoa_KH.FlatAppearance.BorderSize = 0;
            btnXoa_KH.FlatStyle = FlatStyle.Popup;
            btnXoa_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXoa_KH.ForeColor = Color.FromArgb(102, 44, 33);
            btnXoa_KH.Location = new Point(126, 66);
            btnXoa_KH.Name = "btnXoa_KH";
            btnXoa_KH.Size = new Size(80, 42);
            btnXoa_KH.TabIndex = 5;
            btnXoa_KH.Text = "Xoá";
            btnXoa_KH.UseVisualStyleBackColor = false;
            btnXoa_KH.Click += btnXoa_KH_Click;
            // 
            // btnThem_KH
            // 
            btnThem_KH.AutoSize = true;
            btnThem_KH.BackColor = Color.White;
            btnThem_KH.Cursor = Cursors.Hand;
            btnThem_KH.FlatAppearance.BorderSize = 0;
            btnThem_KH.FlatStyle = FlatStyle.Popup;
            btnThem_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThem_KH.ForeColor = Color.FromArgb(102, 44, 33);
            btnThem_KH.Location = new Point(28, 66);
            btnThem_KH.Name = "btnThem_KH";
            btnThem_KH.Size = new Size(80, 42);
            btnThem_KH.TabIndex = 6;
            btnThem_KH.Text = "Thêm";
            btnThem_KH.UseVisualStyleBackColor = false;
            btnThem_KH.Click += btnThem_KH_Click;
            // 
            // panel26
            // 
            panel26.BackColor = Color.FromArgb(255, 241, 230);
            panel26.Controls.Add(btnUser_KH);
            panel26.Controls.Add(btnThoat_KH);
            panel26.Controls.Add(lblUserName_KH);
            panel26.Controls.Add(panel27);
            panel26.Dock = DockStyle.Top;
            panel26.Location = new Point(0, 0);
            panel26.Name = "panel26";
            panel26.Size = new Size(998, 62);
            panel26.TabIndex = 0;
            // 
            // btnUser_KH
            // 
            btnUser_KH.AutoSize = true;
            btnUser_KH.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_KH.BackgroundImage = Properties.Resources.login;
            btnUser_KH.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_KH.ContextMenuStrip = contextMenuStrip1;
            btnUser_KH.Cursor = Cursors.Hand;
            btnUser_KH.FlatAppearance.BorderSize = 0;
            btnUser_KH.FlatStyle = FlatStyle.Flat;
            btnUser_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_KH.ForeColor = Color.White;
            btnUser_KH.Location = new Point(871, 10);
            btnUser_KH.Name = "btnUser_KH";
            btnUser_KH.Size = new Size(66, 42);
            btnUser_KH.TabIndex = 1;
            btnUser_KH.UseVisualStyleBackColor = false;
            btnUser_KH.Click += btnUser_KH_Click;
            // 
            // btnThoat_KH
            // 
            btnThoat_KH.AutoSize = true;
            btnThoat_KH.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_KH.BackgroundImage = Properties.Resources.exit;
            btnThoat_KH.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_KH.Cursor = Cursors.Hand;
            btnThoat_KH.FlatAppearance.BorderSize = 0;
            btnThoat_KH.FlatStyle = FlatStyle.Flat;
            btnThoat_KH.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_KH.ForeColor = Color.White;
            btnThoat_KH.Location = new Point(934, 8);
            btnThoat_KH.Name = "btnThoat_KH";
            btnThoat_KH.Size = new Size(66, 46);
            btnThoat_KH.TabIndex = 1;
            btnThoat_KH.UseVisualStyleBackColor = false;
            btnThoat_KH.Click += btnThoat_KH_Click;
            // 
            // lblUserName_KH
            // 
            lblUserName_KH.AutoSize = true;
            lblUserName_KH.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_KH.Location = new Point(735, 20);
            lblUserName_KH.Name = "lblUserName_KH";
            lblUserName_KH.Size = new Size(119, 26);
            lblUserName_KH.TabIndex = 2;
            lblUserName_KH.Text = "user name";
            // 
            // panel27
            // 
            panel27.Controls.Add(panel28);
            panel27.Controls.Add(label10);
            panel27.Location = new Point(6, 3);
            panel27.Name = "panel27";
            panel27.Size = new Size(403, 51);
            panel27.TabIndex = 3;
            // 
            // panel28
            // 
            panel28.BackgroundImage = Properties.Resources.group_black;
            panel28.BackgroundImageLayout = ImageLayout.Zoom;
            panel28.Location = new Point(12, 3);
            panel28.Name = "panel28";
            panel28.Size = new Size(74, 45);
            panel28.TabIndex = 0;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label10.Location = new Point(83, 15);
            label10.Name = "label10";
            label10.Size = new Size(238, 44);
            label10.TabIndex = 2;
            label10.Text = "Khách Hàng";
            // 
            // tabPage7
            // 
            tabPage7.Controls.Add(pnlLichSu);
            tabPage7.Location = new Point(4, 29);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(1004, 640);
            tabPage7.TabIndex = 6;
            tabPage7.Text = "tabPage7";
            tabPage7.UseVisualStyleBackColor = true;
            // 
            // pnlLichSu
            // 
            pnlLichSu.Controls.Add(dgvLichSu);
            pnlLichSu.Controls.Add(panel29);
            pnlLichSu.Dock = DockStyle.Fill;
            pnlLichSu.Location = new Point(3, 3);
            pnlLichSu.Name = "pnlLichSu";
            pnlLichSu.Size = new Size(998, 634);
            pnlLichSu.TabIndex = 5;
            pnlLichSu.Visible = false;
            // 
            // dgvLichSu
            // 
            dgvLichSu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLichSu.BackgroundColor = Color.FromArgb(217, 186, 166);
            dgvLichSu.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            dataGridViewCellStyle16.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = Color.FromArgb(174, 113, 102);
            dataGridViewCellStyle16.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle16.ForeColor = Color.Transparent;
            dataGridViewCellStyle16.SelectionBackColor = SystemColors.MenuHighlight;
            dataGridViewCellStyle16.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = DataGridViewTriState.True;
            dgvLichSu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            dgvLichSu.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = Color.FromArgb(196, 196, 196);
            dataGridViewCellStyle17.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle17.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = DataGridViewTriState.False;
            dgvLichSu.DefaultCellStyle = dataGridViewCellStyle17;
            dgvLichSu.Dock = DockStyle.Fill;
            dgvLichSu.EnableHeadersVisualStyles = false;
            dgvLichSu.GridColor = Color.FromArgb(217, 186, 166);
            dgvLichSu.Location = new Point(0, 125);
            dgvLichSu.Name = "dgvLichSu";
            dataGridViewCellStyle18.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = Color.FromArgb(183, 119, 107);
            dataGridViewCellStyle18.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle18.ForeColor = SystemColors.InactiveBorder;
            dataGridViewCellStyle18.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = DataGridViewTriState.True;
            dgvLichSu.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            dgvLichSu.RowHeadersVisible = false;
            dgvLichSu.RowHeadersWidth = 51;
            dgvLichSu.Size = new Size(998, 509);
            dgvLichSu.TabIndex = 7;
            // 
            // panel29
            // 
            panel29.BackColor = Color.FromArgb(217, 186, 166);
            panel29.Controls.Add(dtpEnd_LS);
            panel29.Controls.Add(label13);
            panel29.Controls.Add(dtpStart_LS);
            panel29.Controls.Add(label12);
            panel29.Controls.Add(txtTimKiem_LS);
            panel29.Controls.Add(btnXuatExcel_LS);
            panel29.Controls.Add(panel30);
            panel29.Dock = DockStyle.Top;
            panel29.Location = new Point(0, 0);
            panel29.Name = "panel29";
            panel29.Size = new Size(998, 125);
            panel29.TabIndex = 1;
            // 
            // dtpEnd_LS
            // 
            dtpEnd_LS.Format = DateTimePickerFormat.Short;
            dtpEnd_LS.Location = new Point(317, 78);
            dtpEnd_LS.Name = "dtpEnd_LS";
            dtpEnd_LS.Size = new Size(99, 27);
            dtpEnd_LS.TabIndex = 9;
            dtpEnd_LS.ValueChanged += dtpEnd_LS_ValueChanged;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label13.Location = new Point(215, 81);
            label13.Name = "label13";
            label13.Size = new Size(100, 21);
            label13.TabIndex = 8;
            label13.Text = "Đến ngày:";
            // 
            // dtpStart_LS
            // 
            dtpStart_LS.Format = DateTimePickerFormat.Short;
            dtpStart_LS.Location = new Point(108, 78);
            dtpStart_LS.Name = "dtpStart_LS";
            dtpStart_LS.Size = new Size(101, 27);
            dtpStart_LS.TabIndex = 9;
            dtpStart_LS.ValueChanged += dtpStart_LS_ValueChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label12.Location = new Point(6, 81);
            label12.Name = "label12";
            label12.Size = new Size(89, 21);
            label12.TabIndex = 8;
            label12.Text = "Từ ngày:";
            // 
            // txtTimKiem_LS
            // 
            txtTimKiem_LS.BorderStyle = BorderStyle.FixedSingle;
            txtTimKiem_LS.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Italic, GraphicsUnit.Point, 163);
            txtTimKiem_LS.Location = new Point(557, 78);
            txtTimKiem_LS.Multiline = true;
            txtTimKiem_LS.Name = "txtTimKiem_LS";
            txtTimKiem_LS.Size = new Size(255, 27);
            txtTimKiem_LS.TabIndex = 7;
            txtTimKiem_LS.Text = "Tìm kiếm...";
            txtTimKiem_LS.TextChanged += txtTimKiem_LS_TextChanged;
            txtTimKiem_LS.Enter += txtTimKiem_LS_Enter;
            txtTimKiem_LS.Leave += txtTimKiem_LS_Leave;
            // 
            // btnXuatExcel_LS
            // 
            btnXuatExcel_LS.AutoSize = true;
            btnXuatExcel_LS.BackColor = Color.White;
            btnXuatExcel_LS.Cursor = Cursors.Hand;
            btnXuatExcel_LS.FlatAppearance.BorderSize = 0;
            btnXuatExcel_LS.FlatStyle = FlatStyle.Popup;
            btnXuatExcel_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnXuatExcel_LS.ForeColor = Color.FromArgb(102, 44, 33);
            btnXuatExcel_LS.Image = Properties.Resources.excel1;
            btnXuatExcel_LS.ImageAlign = ContentAlignment.MiddleLeft;
            btnXuatExcel_LS.Location = new Point(849, 70);
            btnXuatExcel_LS.Name = "btnXuatExcel_LS";
            btnXuatExcel_LS.Size = new Size(144, 42);
            btnXuatExcel_LS.TabIndex = 4;
            btnXuatExcel_LS.Text = "Xuất Excel";
            btnXuatExcel_LS.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnXuatExcel_LS.UseVisualStyleBackColor = false;
            btnXuatExcel_LS.Click += btnXuatExcel_LS_Click;
            // 
            // panel30
            // 
            panel30.BackColor = Color.FromArgb(255, 241, 230);
            panel30.Controls.Add(btnUser_LS);
            panel30.Controls.Add(btnThoat_LS);
            panel30.Controls.Add(lblUserName_LS);
            panel30.Controls.Add(panel31);
            panel30.Dock = DockStyle.Top;
            panel30.Location = new Point(0, 0);
            panel30.Name = "panel30";
            panel30.Size = new Size(998, 62);
            panel30.TabIndex = 0;
            // 
            // btnUser_LS
            // 
            btnUser_LS.AutoSize = true;
            btnUser_LS.BackColor = Color.FromArgb(255, 241, 230);
            btnUser_LS.BackgroundImage = Properties.Resources.login;
            btnUser_LS.BackgroundImageLayout = ImageLayout.Stretch;
            btnUser_LS.ContextMenuStrip = contextMenuStrip1;
            btnUser_LS.Cursor = Cursors.Hand;
            btnUser_LS.FlatAppearance.BorderSize = 0;
            btnUser_LS.FlatStyle = FlatStyle.Flat;
            btnUser_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnUser_LS.ForeColor = Color.White;
            btnUser_LS.Location = new Point(871, 10);
            btnUser_LS.Name = "btnUser_LS";
            btnUser_LS.Size = new Size(66, 42);
            btnUser_LS.TabIndex = 1;
            btnUser_LS.UseVisualStyleBackColor = false;
            btnUser_LS.Click += btnUser_LS_Click;
            // 
            // btnThoat_LS
            // 
            btnThoat_LS.AutoSize = true;
            btnThoat_LS.BackColor = Color.FromArgb(255, 241, 230);
            btnThoat_LS.BackgroundImage = Properties.Resources.exit;
            btnThoat_LS.BackgroundImageLayout = ImageLayout.Stretch;
            btnThoat_LS.Cursor = Cursors.Hand;
            btnThoat_LS.FlatAppearance.BorderSize = 0;
            btnThoat_LS.FlatStyle = FlatStyle.Flat;
            btnThoat_LS.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            btnThoat_LS.ForeColor = Color.White;
            btnThoat_LS.Location = new Point(934, 8);
            btnThoat_LS.Name = "btnThoat_LS";
            btnThoat_LS.Size = new Size(66, 46);
            btnThoat_LS.TabIndex = 1;
            btnThoat_LS.UseVisualStyleBackColor = false;
            btnThoat_LS.Click += btnThoat_LS_Click;
            // 
            // lblUserName_LS
            // 
            lblUserName_LS.AutoSize = true;
            lblUserName_LS.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 163);
            lblUserName_LS.Location = new Point(735, 20);
            lblUserName_LS.Name = "lblUserName_LS";
            lblUserName_LS.Size = new Size(119, 26);
            lblUserName_LS.TabIndex = 2;
            lblUserName_LS.Text = "user name";
            // 
            // panel31
            // 
            panel31.Controls.Add(panel32);
            panel31.Controls.Add(label11);
            panel31.Location = new Point(6, 3);
            panel31.Name = "panel31";
            panel31.Size = new Size(403, 51);
            panel31.TabIndex = 3;
            // 
            // panel32
            // 
            panel32.BackgroundImage = Properties.Resources.history_black;
            panel32.BackgroundImageLayout = ImageLayout.Zoom;
            panel32.Location = new Point(12, 3);
            panel32.Name = "panel32";
            panel32.Size = new Size(74, 45);
            panel32.TabIndex = 0;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label11.Location = new Point(83, 15);
            label11.Name = "label11";
            label11.Size = new Size(158, 44);
            label11.TabIndex = 2;
            label11.Text = "Lịch Sử";
            // 
            // fHome
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            BackgroundImageLayout = ImageLayout.Center;
            ClientSize = new Size(1262, 673);
            Controls.Add(tabControl1);
            Controls.Add(panel1);
            DoubleBuffered = true;
            Name = "fHome";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Home";
            FormClosing += fHome_FormClosing;
            Load += fHome_Load;
            panel1.ResumeLayout(false);
            tabPage4.ResumeLayout(false);
            pnlKhuyenMai.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvKhuyenMai).EndInit();
            panel17.ResumeLayout(false);
            panel17.PerformLayout();
            panel18.ResumeLayout(false);
            panel18.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            panel19.ResumeLayout(false);
            panel19.PerformLayout();
            tabPage3.ResumeLayout(false);
            pnlNhanVien.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvNhanVien).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            tabPage2.ResumeLayout(false);
            pnlQuanLyBan.ResumeLayout(false);
            pnl_top_QuanLyban.ResumeLayout(false);
            pnl_top_QuanLyban.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            tabPage1.ResumeLayout(false);
            pnlThucDon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvThucDon).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            pnlKho.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvKho).EndInit();
            panel21.ResumeLayout(false);
            panel21.PerformLayout();
            panel22.ResumeLayout(false);
            panel22.PerformLayout();
            panel23.ResumeLayout(false);
            panel23.PerformLayout();
            tabPage6.ResumeLayout(false);
            pnlKhachHang.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvKhachHang).EndInit();
            panel25.ResumeLayout(false);
            panel25.PerformLayout();
            panel26.ResumeLayout(false);
            panel26.PerformLayout();
            panel27.ResumeLayout(false);
            panel27.PerformLayout();
            tabPage7.ResumeLayout(false);
            pnlLichSu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvLichSu).EndInit();
            panel29.ResumeLayout(false);
            panel29.PerformLayout();
            panel30.ResumeLayout(false);
            panel30.PerformLayout();
            panel31.ResumeLayout(false);
            panel31.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel3;
        private Button btnThucDon;
        private Button btnKho;
        private Button btnQuanLyBan;
        private Button btnKhachHang;
        private Button btnNhanVien;
        private Button btnLichSu;
        private Button btnKhuyenMai;
        private Panel panel1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private TabPage tabPage4;
        private Panel pnlKhuyenMai;
        private Panel panel17;
        private TextBox txtTimKiem_KM;
        private Button btnSua_KM;
        private Button btnXoa_KM;
        private Button btnThem_KM;
        private Panel panel18;
        private Button btnUser_KM;
        private Button btnThoat_KM;
        private Label lblUserName_KM;
        private Panel panel19;
        private Panel panel20;
        private Label label8;
        private TabPage tabPage3;
        private Panel pnlNhanVien;
        private Panel panel6;
        private TextBox txtTimKiem_NhanVien;
        private Button btnSua_NhanVien;
        private Button btnXoa_NhanVien;
        private Button btnThem_NhanVien;
        private Panel panel7;
        private Button btnUser_NhanVien;
        private Button btnThoat_NhanVien;
        private Label lblUserName_NhanVien;
        private Panel panel15;
        private Panel panel16;
        private Label label3;
        private TabPage tabPage2;
        private Panel pnlQuanLyBan;
        private Panel pnl_top_QuanLyban;
        private Label label5;
        private Label label4;
        private Panel panel9;
        private Panel panel8;
        private ComboBox cboQuanLyBan;
        private Panel panel4;
        private Button btnUser_Ban;
        private Button btnThoat_Ban;
        private Label lblUserName_Ban;
        private Panel panel14;
        private Panel panel13;
        private Label label1;
        private Button btnSua_Ban;
        private Button btnThem_Ban;
        private TabPage tabPage1;
        private Panel pnlThucDon;
        private Panel panel5;
        private ComboBox cbo_ThucDon;
        private TextBox txtTimKiem_ThucDon;
        private Button btnSua_ThucDon;
        private Button btnXoa_ThucDon;
        private Button btnThem_ThucDon;
        private Panel panel10;
        private Button btnUser_ThucDon;
        private Button btnThoat_ThucDon;
        private Label lblUserName_TD;
        private Panel panel11;
        private Panel panel12;
        private Label label7;
        private TabControl tabControl1;
        private TabPage tabPage5;
        private Panel pnlKho;
        private Panel panel21;
        private TextBox txtTimKiem_Kho;
        private Panel panel22;
        private Button btnUser_Kho;
        private Button btnThoat_Kho;
        private Label lblUserName_Kho;
        private Panel panel23;
        private Panel panel24;
        private Label label9;
        private TabPage tabPage6;
        private Button btnXuatExcel_LS;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button btnUser_LS;
        private Button btnThoat_LS;
      
        private Panel pnlKhachHang;
        private DataGridView dgvKho;
        private Panel panel25;
        private Button button9;
        private Button btnXoa_KH;
        private Button btnThem_KH;
        private Panel panel26;
        private Button btnUser_KH;
        private Button btnThoat_KH;
        private Label lblUserName_KH;
        private Panel panel27;
        private Panel panel28;
        private Label label10;
     
        private TabPage tabPage7;
        private Panel pnlLichSu;
        private Panel panel29;
        private DateTimePicker dtpEnd_LS;
        private Label label13;
        private DateTimePicker dtpStart_LS;
        private Label label12;
        private TextBox txtTimKiem_LS;
        private Panel panel30;
        private Label lblUserName_LS;
        private Panel panel31;
        private Panel panel32;
        private Label label11;
        private Button btnSua_KH;
        private TextBox txtTimKiem_KH;
        private DataGridView dgvThucDon;
        private FlowLayoutPanel flpQuanLyBan;
        private DataGridView dgvNhanVien;
        private DataGridView dgvKhuyenMai;
        private DataGridView dgvKhachHang;
        private DataGridView dgvLichSu;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem toolStripMenuItem1;
        private ToolStripMenuItem toolStripMenuItem2;
        private Button btnXoa_Ban;
        private Button btnCapNhat_Kho;
    }
}